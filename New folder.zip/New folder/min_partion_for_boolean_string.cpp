#include<bits/stdc++.h>
using namespace std;


int func(string s,int i,int j,bool tf,int dp[2][20][20]){
    int x=tf==true?1:0;
    if(dp[x][i][j]!=-1){
        return dp[x][i][j];
    }
    if(i>j){
        return dp[x][i][j]= 0;
    }
    else if(i==j){
        if(tf==true && s[i]=='T'){
            return dp[x][i][j]= 1;
        }
        else if(tf==false && s[i]=='F'){
            return dp[x][i][j]= 1;
        }
        else{
            return dp[x][i][j]= 0;
        }
    }
    else{
        int ans=0;
        for(int k=i+1;k<j;k+=2){
            int lt=func(s,i,k-1,true,dp);
            int lf=func(s,i,k-1,false,dp);
            int rt=func(s,k+1,j,true,dp);
            int rf=func(s,k+1,j,false,dp);
            if(s[k]=='&'){
                if(tf==true){
                    ans+=rt*lt;
                }
                else{
                    ans+=rf*lf+rt*lf+lt*rf;
                }
            }
            else if(s[k]=='|'){
                if(tf==true){
                    ans+=rt*lf+lt*rf+rt*lt;
                }
                else{
                    ans+=rf*lf;
                }
            }
            else if(s[k]=='^'){
                if(tf==true){
                    ans+=lf*rt+rf*lt;
                }
                else{
                    ans+=lf*rf+lt*rt;
                }
            }
        }
        return dp[x][i][j]= ans;
    }
}

int main(){
    int dp[2][20][20];
    memset(dp,-1,sizeof(dp));
    string s="F^F^F^F^F^F";
    int n=s.length();
    cout<<func(s,0,n-1,false,dp);
    return 0;
}