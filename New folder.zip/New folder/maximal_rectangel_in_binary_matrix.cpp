#include <bits/stdc++.h>
using namespace std;

int func(vector<int> v)
{
    int n = v.size();
    stack<int> st;
    st.push(-1);
    vector<int> ans_left, ans_right;
    for (int i = 0; i < n; i++)
    {
        if (st.top() != -1)
        {
            if (v[st.top()] < v[i])
            {
                ans_left.push_back(st.top());
                st.push(i);
            }
            else
            {
                while (st.top() >= 0 && v[st.top()] >= v[i])
                {
                    st.pop();
                }
                if (st.top() == -1)
                {
                    ans_left.push_back(-1);
                    st.push(i);
                }
                else if (v[st.top()] < v[i])
                {
                    ans_left.push_back(st.top());
                    st.push(i);
                }
            }
        }
        else
        {
            ans_left.push_back(-1);
            st.push(i);
        }
    }

    stack<int> st1;
    st1.push(-1);

    for (int i = n - 1; i >= 0; i = i - 1)
    {
        if (st1.top() != -1)
        {
            if (v[st1.top()] < v[i])
            {
                ans_right.push_back(st1.top());
                st1.push(i);
            }
            else
            {
                while (st1.top() >= 0 && v[st1.top()] >= v[i])
                {
                    if (v[st1.top()] >= v[i])
                    {
                        st1.pop();
                    }
                    else
                    {
                        break;
                    }
                }
                if (st1.top() == -1)
                {
                    ans_right.push_back(-1);
                    st1.push(i);
                }
                else if (v[st1.top()] < v[i])
                {
                    ans_right.push_back(st1.top());
                    st1.push(i);
                }
            }
        }
        else
        {
            ans_right.push_back(-1);
            st1.push(i);
        }
    }
    reverse(ans_right.begin(), ans_right.end());

    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        if (ans_right[i] == -1)
        {
            ans_right[i] = n;
        }
        ans = max(ans, v[i] * (ans_right[i] - ans_left[i] - 1));
    }

    return ans;
}

int main()
{
    vector<vector<char>> mt={{'1','0','1','0'},{'0','1','1','1'},{'1','0','0','1'},{'1','1','1','1'}};
    int m = mt.size();
    int n = mt[0].size();
    vector<vector<int>> mtr;
    for (int i = 0; i < m; i++)
    {
        vector<int> v = {};
        for (int j = 0; j < n; j++)
        {
            if (mt[i][j] == '0')
            {
                v.push_back(0);
            }
            else
            {
                v.push_back(1);
            }
        }
        mtr.push_back(v);
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i > 0)
            {
                if (mtr[i][j] == 1)
                {
                    mtr[i][j]=1+ mtr[i - 1][j];
                }
            }
        }
    }
    int ans = 0;
    for (int j = 0; j < m; j++)
    {
        ans = max(ans, func(mtr[j]));
    }

    cout<< ans;
}