#include<bits/stdc++.h>
using namespace std;
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}


void func(vector<vector<int>> &g,int r,int c){
    if(r<0 || c<0 || r>=g.size() || c>=g[0].size())return;
    if(g[r][c]==0)return;
    g[r][c]=0;
    func(g,r+1,c);
    func(g,r-1,c);
    func(g,r,c+1);
    func(g,r,c-1);
}





int main(){
    init_code();
    int m,n;
    cin>>m>>n;
    vector<vector<int>> g(m,vector<int> (n));
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>g[i][j];
        }
    } 
    int count=0;
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            if(g[i][j]==1){
                count++;
                func(g,i,j);
            }
        }
    }
    cout<<count<<endl;
    return 0;
}