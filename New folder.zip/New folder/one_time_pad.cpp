#include<iostream>
using namespace std;


string expander(string s,int n){
    int n1=s.size();
    string s1="";
    int n2=n/n1;
    for(int i=0;i<n2;i++){
        s1+=s;
    }
    int n3=n%n1;
    for(int i=0;i<n3;i++){
        s1.push_back(s[i]);
    }
    return s1;
}





int main(){
    cout<<expander("100101",10);
    return 0;
}