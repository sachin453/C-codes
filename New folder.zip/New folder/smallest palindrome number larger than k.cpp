#include<iostream>
using namespace std;

string adder(string s,int low,int high){
    int carr=1;
    for(int i=high;i>=low;i--){
        if(carr+int(s[i])-48<=9){
            s[i]=char(carr+int(s[i]));
            carr=0;
            break;
        }
        else{
            s[i]=char((carr+int(s[i])-48)%10+48);
            carr=1;
        }
    }
    if(carr==1){
            s="1"+s;
        }
    return s;
}



string palin(string s,int low,int high){
    if(low>=high){
        return s;
    }
    else{
        if(s[low]==s[high]){
            return palin(s,low+1,high-1);
        }
        else{
            if(int(s[low])>=int(s[high])){
                s[high]=s[low];
                return palin(s,low+1,high-1);
            }
            else{
                while(s[low]!=s[high]){
                    s=adder(s,low,high);
                }
                return palin(s,low+1,high-1);
            }
        }
    }
}


int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        string s;
        cin>>s;
        int x=1;
        for(int i=0;i<n;i++){
            if(s[i]!='9'){
                x=0;
                break;
            }
        }
        if(x==1){
            s=adder(s,0,n-1);
            n++;
        }
        cout<<palin(s,0,n-1)<<endl;
    }
    return 0;
}