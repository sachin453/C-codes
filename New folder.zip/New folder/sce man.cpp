#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}




int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        int n,m;
        cin>>n>>m;
        unordered_map<int,int> mp;
        vi tasks=scan_vec(m);
        for(int i=0;i<m;i++){
            mp[tasks[i]]++;
        }
        vi tpw(n+1);
        for(int i=1;i<=n;i++){
            tpw[i]=mp[i];
        }
        sort(tpw.begin(),tpw.end());
        int mini=1,maxi=n;
        while(tpw[maxi]-tpw[mini]>=2){
            tpw[maxi]--;
            tpw[mini]+=2;
            if(mini+1<tpw.size()){
                while(tpw[mini+1]<tpw[mini] && mini+1<tpw.size()){
                    mini++;
                }
            }
            while(tpw[mini-1]<tpw[mini] && mini-1>=1){
                mini--;
            }
            if(maxi+1<tpw.size()){
                while(tpw[maxi+1]<tpw[maxi] && maxi+1<tpw.size()){
                    maxi++;
                }
            }
            while(tpw[maxi-1]>tpw[maxi] && maxi-1>=1){
                maxi--;
            }
        }
        int ans=0;
        for(int i=1;i<tpw.size();i++){
            if(ans<tpw[i]){
                ans=tpw[i];
            }
        }
        cout<<ans<<endl;
        
    }
	return 0;
}
