#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){
    return a>b?a:b;
}
int min(int a,int b){
    return a>b?b:a;
}






int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        int n,s;
        cin>>n>>s;
        vi nums(n);
        int total_sum=0;
        for(int i=0;i<n;i++){
            cin>>nums[i];
            total_sum+=nums[i];
        }
        if(total_sum<s){
            cout<<-1<<endl;
        }
        else if(total_sum==s){
            cout<<0<<endl;
        }
        else{
            vi left(total_sum+1),right(total_sum+1);
            left[0]=0;
            right[0]=0;
            int left_sum=0,right_sum=0;
            for(int i=0;i<n;i++){
                if(nums[i]==1){
                    left_sum++;
                    left[left_sum]=i+1;
                }
                int j=n-i-1;
                if(nums[j]==1){
                    right_sum++;
                    right[right_sum]=n-j;
                }
            }
            int to_remove=total_sum-s;
            int ans=10000000;
            for(int i=0;i<=to_remove;i++){
                ans=min(ans,left[i]+right[to_remove-i]);
            }
            cout<<ans<<endl;
        }
    }
	return 0;
}
