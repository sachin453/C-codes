#include<iostream>
using namespace std;

string temp(string s){
    char c1=s[0];
    char c2=s[s.size()-1];
    int n=s.size()-2;
    string s1="";
    s1.push_back(c1);
    if(n<10){
        char ci=(char)(n+48);
        s1.push_back(ci);
    }
    else if(n<99){
        char ci=(char)(n%10+48);
        char cj=(char)(n/10+48);
        s1.push_back(cj);
        s1.push_back(ci);
    }
    s1.push_back(c2);
    return s1;
}


int main(){
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        string s;
        cin>>s;
        if(s.size()<=10){
            cout<<s<<endl;
        }
        else{
            cout<<temp(s)<<endl;
        }
    }
    return 0;
}