#include<iostream>
#include<vector>
using namespace std;

int or_calc(int a,int b){
    vector<int> sa,sb;
    while(a!=0 || b!=0){
        sa.push_back(a%2);
        a=a/2;
        sb.push_back(b%2);
        b=b/2;
    }
    vector<int> ab_or;
    for(int i=0;i<sa.size();i++){
        if(sa[i]==0 && sb[i]==0){
            ab_or.push_back(0);
        }
        else{
            ab_or.push_back(1);
        }
    }
    int ans=0;
    for(int i=ab_or.size()-1;i>=0;i--){
        ans=ans*2+ab_or[i];
    }
    return ans;
}




int main(){
    int t;
    cin>>t;
    while(t--){
        int n,z;
        cin>>n>>z;
        vector<int> a(n);
        for(int i=0;i<n;i++){
            cin>>a[i];
        }
        int ans=or_calc(a[0],z);
        for(int i=0;i<n;i++){
            if(or_calc(a[i],z)>ans){
                ans=or_calc(a[i],z);
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}