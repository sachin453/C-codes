#include<bits/stdc++.h>
using namespace std;


bool check_simple(string s1,string s2){ // if s2 is sub sequence of s1
    int n1=s1.length();int n2=s2.length();
    int i=0;int j=0;
    while(i<n1 && j<n2){
        if(s1[i]==s2[j]){
            i++;j++;
        }
        else{
            i++;
        }
    }
    if(j==n2){
        return true;
    }
    return false;
}


bool check_recursion(string s1,string s2){
    int n1=s1.length();int n2=s2.length();
    if(n2>n1){
        return false;
    }
    else if(n2==0){
        return true;
    }
    else{
        if(s1[n1-1]==s2[n2-1]){
            s1.pop_back();
            s2.pop_back();
            return check_recursion(s1,s2);
        }
        else{
            s1.pop_back();
            return check_recursion(s1,s2);
        }
    }
}


int main(){
    string s1="adxcpyxxtQFAB";
    string s2="axyt";
    cout<<check_simple(s1,s2)<<" <-+-> "<<check_recursion(s1,s2);
    return 0;
}