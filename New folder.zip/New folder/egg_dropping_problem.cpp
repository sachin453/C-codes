#include <bits/stdc++.h>
using namespace std;

int solve(int e, int f, int dp[20][20])
{
    if (dp[e][f] != -1)
    {
        return dp[e][f];
    }
    if (f < 1 || e < 1)
    {
        return dp[e][f] = 0;
    }
    else if (e == 1)
    {
        return dp[e][f] = f;
    }
    else
    {
        int ans = INT_MAX;
        for (int k = 1; k <= f; k++)
        {
            int b = solve(e - 1, k - 1, dp);
            int t = solve(e, f - k, dp);
            ans = min(ans, 1 + max(t, b));
        }
        return dp[e][f] = ans;
    }
}

int main()
{
    int dp[20][20];
    memset(dp, -1, sizeof(dp));
    int e = 2;
    int f = 10;
    cout << solve(e, f, dp);

    return 0;
}