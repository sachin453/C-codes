#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define vll vector<ll>
#define vi vector<int>
#define pb push_back
using namespace std;
int max(int a, int b)
{ // max of two ints
    return a > b ? a : b;
}
int min(int a, int b)
{ // min of two ints
    return a > b ? b : a;
}
vi scan_vec(int n)
{ // scan and return a vector of length n
    vi v(n);
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    return v;
}
void print_vec(vi v)
{ // prints the given vector
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}
vector<int> get_vec_range(int a, int b)
{                    // returns a vector containing intergers in range [a,b]
    vector<int> ans; // in increasing order
    for (int i = a; i <= b; i++)
    {
        ans.push_back(i);
    }
    return ans;
}
vi smaller_in_left(vi arr)
{
    int n = arr.size();
    vi ans;
    stack<int> st;
    st.push(-1);
    for (int i = 0; i < n; i++)
    {
        if (st.top() != -1)
        {
            if (arr[st.top()] < arr[i])
            {
                ans.pb(st.top());
                st.push(i);
            }
            else
            {
                while (st.top() != -1 && arr[st.top()] >= arr[i])
                {
                    st.pop();
                }
                if (st.top() == -1)
                {
                    ans.pb(-1);
                    st.push(i);
                }
                else
                {
                    ans.pb(st.top());
                    st.push(i);
                }
            }
        }
        else
        {
            ans.pb(-1);
            st.push(i);
        }
    }
    return ans;
}
vi smaller_in_right(vi arr)
{
    int n = arr.size();
    vi ans;
    stack<int> st;
    st.push(-1);
    for (int i = n - 1; i >= 0; i--)
    {
        if (st.top() != -1)
        {
            if (arr[st.top()] < arr[i])
            {
                ans.pb(st.top());
                st.push(i);
            }
            else
            {
                while (st.top() != -1 && arr[st.top()] >= arr[i])
                {
                    st.pop();
                }
                ans.pb(st.top());
                st.push(i);
            }
        }
        else
        {
            ans.pb(st.top());
            st.push(i);
        }
    }
    reverse(ans.begin(), ans.end());
    return ans;
}

void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}

string func(string A, string B) {
    int n=A.size();
    int m=B.size();
    int dp[n][m];
    memset(dp,0,sizeof(dp));
    for(int i=n-1;i>=0;i--){
        for(int j=m-1;j>=0;j--){
            if(i==n-1 && j==m-1){
                if(A[i]==B[j]){
                    dp[i][j]=1;
                }
                else{
                    dp[i][j]=0;
                }
            }
            else if(i==n-1){
                if(A[i]==B[j]){
                    dp[i][j]=1;
                }
                else{
                    dp[i][j]=dp[i][j+1];
                }
            }
            else if(j==m-1){
                if(A[i]==B[j]){
                    dp[i][j]=1;
                }
                else{
                    dp[i][j]=dp[i+1][j];
                }
            }
            else{
                if(A[i]==B[j]){
                    dp[i][j]=dp[i+1][j+1]+1;
                }
                else{
                    //dp[i][j]=max(dp[i+1][j],dp[i][j+1]);
                    int x1=dp[i+1][j];
                    int x2=dp[i][j+1];
                    if(x1==x2){
                        dp[i][j]=x1;
                    }
                    else{
                        dp[i][j]=max(x1,x2);
                    }
                }
            }
        }
    }
    string ans;
    int i=0;int j=0;
    while(i<n && j<m){
        if(A[i]==B[j]){
            ans.push_back(A[i]);
            i++;
            j++;
        }
        else{
            if(dp[i+1][j]<dp[i][j+1]){
                j++;
            }
            else{
                i++;
            }
        }
    }
    // for(int i=0;i<n;i++){
    //     for(int j=0;j<m;j++){
    //         cout<<dp[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }
    return ans;
}

int main()
{
    //init_code();
    // your code goes here
    string A,B;
    A="ba";
    B="aa";
    string C=func(A,B);
    int n=C.size();
    vector<int> numsA,numsB;
    int count=0;int ind=0;
    for(int i=0;i<A.size();i++){
        if(A[i]==C[ind] && ind<C.size()){
            numsA.push_back(count);
            count=0;
            ind++;
        }
        else{
            count++;
        }
        if(i==A.size()-1){
            numsA.push_back(count);
            count=0;
        }
    }
    ind=0;count=0;
    for(int i=0;i<B.size();i++){
        if(B[i]==C[ind] && ind<C.size()){
            numsB.push_back(count);
            count=0;
            ind++;
        }
        else{
            count++;
        }
        if(i==B.size()-1){
            numsB.push_back(count);
            count=0;
        }
    }
    int fans=0;
    for(int i=0;i<n+1;i++){
        if(numsA[i]==numsB[i]){
            fans+=numsA[i];
        }
        else if(numsA[i]>numsB[i]){
            fans+=numsA[i]-numsB[i];
        }
        else{
            fans+=numsB[i]-numsA[i];
        }
    }
    cout<<C<<endl;
    print_vec(numsA);
    print_vec(numsB);
    cout<<fans<<endl;
    return 0;
}