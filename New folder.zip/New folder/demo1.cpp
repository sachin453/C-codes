#include <bits/stdc++.h>
using namespace std;

int func(vector<int> A,vector<int> B){
    map<int,int> mp,max_cost;
    int x=0;
    vector<int> marks;
    for(int i=0;i<A.size();i++){
        if(mp[A[i]]==0){
            x++;
            max_cost[A[i]]=i;
        }
        mp[A[i]]++;
        if(mp[A[i]]>1){
            marks.push_back(A[i]);
            if(B[max_cost[A[i]]]<B[i]){
                max_cost[A[i]]=i;
            }
        }
    }
    sort(marks.begin(),marks.end());
    vector<int> v;
    for(int i=0;i<A.size();i++){
        if(mp[A[i]]>1 && max_cost[A[i]]!=i){
            v.push_back(B[i]);
        }
    }
    
    
    
    
    
    
    int j=0;
    //sort(marks.begin(),marks.end());
    vector<int> for_marks(marks.size()),diffr(marks.size());
    for(int i=0;i<marks.size();i++){
        j=max(marks[i]+1,j+1);
        while(mp[j]>0){
            j++;
        }
        mp[j]=1;
        for_marks[i]=j;
        diffr[i]=j-marks[i];
    }
    for(int i=0;i<A.size();i++){
        cout<<max_cost[A[i]]<<" ";
    }
    
    return 0;
}


int main() {
	// your code goes here
	vector<int> A,B;
	A={8,8,9,10,10,1,2,3,4,4,5,8};
	B={6,2,1,2,3,4,5,6,7,8,9,3};
	func(A,B);
	return 0;
}
