#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
using namespace std;

int brute_force(vector<int> v)
{
    int n = v.size();
    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        int maxa = 0;
        for (int j = n - 1; j >= i; j--)
        {
            if (v[j] >= v[i])
            {
                maxa = j - i;
                break;
            }
        }
        ans = max(ans, maxa);
    }
    return ans;
}

int nlogn(vector<int> arr)
{
    int n = arr.size();
    if (n == 1)
    {
        return 0;
    }
    vector<vector<int>> v(n, vector<int>(2));
    for (int i = 0; i < n; i++)
    {
        v[i][0] = arr[i];
        v[i][1] = i;
    }
    sort(v.begin(), v.end());
    int ans = 0, min_val = v[0][1];
    for (int i = 0; i < n; i++)
    {
        if (v[i][1] < min_val)
        {
            min_val = v[i][1];
        }
        ans = ans > v[i][1] - min_val ? ans : v[i][1] - min_val;
    }
    return ans > 0 ? ans : 0;
}

int linear_time(vector<int> arr)
{
    int n = arr.size();
    int maxDiff;
    int i, j;
    int *LMin = new int[(sizeof(int) * n)];
    int *RMax = new int[(sizeof(int) * n)];
    LMin[0] = arr[0];
    for (i = 1; i < n; ++i)
    {
        LMin[i] = min(arr[i], LMin[i - 1]);
    }

    RMax[n - 1] = arr[n - 1];
    for (j = n - 2; j >= 0; --j)
    {
        RMax[j] = max(arr[j], RMax[j + 1]);
    }
    i = 0, j = 0, maxDiff = -1;
    while (j < n && i < n)
    {
        if (LMin[i] <= RMax[j])
        {
            maxDiff = max(maxDiff, j - i);
            j = j + 1;
        }
        else
        {
            i = i + 1;
        }
    }

    return maxDiff;
}

int correct_sol(vector<int> v)
{
    int n = v.size();
    vector<int> left(n), right(n);
    left[0] = v[0];
    right[n - 1] = v[n - 1];
    for (int i = 1; i < n; i++)
    {
        left[i] = min(left[i - 1], v[i]);
        right[n - 1 - i] = max(right[n - i], v[i]);
    }
    int i = 0, j = 0;
    int ans = 0;
    while (i < n && j < n)
    {
        if (left[i] <= right[j])
        {
            ans = max(ans, j - i);
            j++;
        }
        else
        {
            i++;
        }
    }
    return ans;
}

int main()
{
    vector<int> v = {9, 9, 1, 2, 8, 8, 8, 8, 3, 9, 9};
    cout << brute_force(v) << endl;
    cout << nlogn(v) << endl;
    cout << linear_time(v) << endl;
    cout << correct_sol(v) << endl;
    return 0;
}