#include<bits/stdc++.h>
using namespace std;



int if_scrambled(string A,string B,int l,int r,vector<vector<int>> &dp){
    if(dp[l][r]!=-1){
        return dp[l][r];
    }
    if(l==r){
        if(A[l]==B[l]){
            return dp[l][r]= 1;
        }
        else{
            return dp[l][r]= 0;
        }
    }
    string Bo=B.substr(l,r-l+1);
    string Ao=A.substr(l,r-l+1);
    if(Bo==Ao){
        return dp[l][r]= 1;
    }
    int ans=0;
    for(int k=l;k<r;k++){
        int temp=0;
        string Al=A.substr(l,k-l+1);
        string Ar=A.substr(k+1,r-k);
        Ar+=Al;
        if(Bo==Ar){
            return dp[l][r]= 1;
        }
        temp=min(if_scrambled(A,B,l,k,dp) , if_scrambled(A,B,k+1,r,dp));
        ans=max(temp,ans);
    }
    return dp[l][r]= ans;
}






int main(){
    string A="abbbcbaaccacaacc",B="acaaaccabcabcbcb";
    vector<vector<int>> dp(A.size(),vector<int> (A.size(),-1));
    int ans=if_scrambled(A,B,0,A.size()-1,dp);
    cout<<ans;
    return 0;
}