#include<bits/stdc++.h>
using namespace std;



int func(string A,string B,int a,int b,vector<vector<int>> &dp){
    if(a>=A.size() || b>=B.size()){
        return 0;
    }
    if(dp[a][b]!=-1){
        return dp[a][b];
    }
    else if(A[a]==B[b]){
        if(a!=b){
            return dp[a][b]= 1+func(A,B,a+1,b+1,dp);
        }
        else{
            return dp[a][b]= func(A,B,a+1,b,dp);
        }
    }
    else{
        int x=func(A,B,a+1,b,dp);
        int y=func(A,B,a,b+1,dp);
        return dp[a][b]= max(x,y);
    }
    return 0;
}


int main(){
    string S="aabb";
    vector<vector<int>> dp(S.size(),vector<int> (S.size(),-1));
    int ans=func(S,S,0,0,dp);
    cout<<ans;
    return 0;
}