#include<bits/stdc++.h>

using namespace std;

int func(vector<int> nums){
    if(nums.size()==1){
        return nums[0];
    }
    int minm=nums[0],maxm=nums[0];
    int n=nums.size();
    int ans=maxm;
    for(int i=1;i<n;i++){
        maxm=max(nums[i],nums[i]*maxm);
        minm=min(nums[i],nums[i]*minm);
        ans=max(maxm,ans);
    }
    return ans;
}





int main(){
    vector<int> nums={1,-2,3,-4,5,0,6,7,8,-9};
    cout<<func(nums);
    return 0;
}