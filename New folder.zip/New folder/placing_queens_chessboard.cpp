#include <bits/stdc++.h>
using namespace std;

bool temp(int i, int j, int a, int b)
{
    int p = i > a ? i - a : a - i;
    int q = j > b ? j - b : b - j;
    return p == q;
}

vector<vector<int>> temp2(vector<vector<int>> V, int p, int q, int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i == p || j == q || temp(i, j, p, q)==true)
            {
                V[i][j] = -1;
            }
        }
    }
    return V;
}

void func(vector<vector<int>> V, vector<vector<vector<int>>> &ans, int i, int n,int x)
{
    if (i == n - 1)
    {
        for (int j = 0; j < n; j++)
        {
            if (V[i][j] == 0)
            {
                V[i][j] = 1;
                x++;
                break;
            }
        }
        if(x==n){
            ans.push_back(V);
        }
    }
    else
    {
        for (int j = 0; j < n; j++)
        {
            vector<vector<int>> v=V;
            if (v[i][j] == 0)
            {
                v = temp2(v, i, j, n);
                v[i][j] = 1;
                func(v, ans, i + 1, n,x+1);
            }
        }
    }
}

int main()
{
    int n=9;
    vector<vector<vector<int>>> ans = {};
    vector<vector<int>> V;
    vector<int> V1(n, 0);
    for (int j = 0; j < n; j++)
    {
        V.push_back(V1);
    }
    func(V, ans, 0, n,0);
    for(int i=0;i<ans.size();i++){
        for(int j=0;j<n;j++){
            for(int k=0;k<n;k++){
                cout<<ans[i][j][k]<<" ";
            }
            cout<<endl;
        }
        cout<<endl<<endl;
    }
    return 0;
}