#include <bits/stdc++.h>
using namespace std;

int main()
{
    vector<int> v = {9, 1, 8, 2, 7, 3, 6, 4, 5};
    stack<int> st;
    st.push(-1);
    st.push(5);
    vector<int> ans = {};
    ans.push_back(-1);
    for (int i = v.size() - 1; i >= 0; i--)
    {
        if (v[i] > st.top())
        {
            ans.push_back(st.top());
            st.push(v[i]);
        }
        else
        {
            while (st.top() >= 0 && st.top() >= v[i])
            {
                st.pop();
            }
            if (st.top() == -1)
            {
                ans.push_back(-1);
                st.push(v[i]);
            }
            else if (st.top() < v[i])
            {
                ans.push_back(st.top());
                st.push(v[i]);
            }
        }
    }
    //reverse(ans.begin(), ans.end());
    for (int j = 0; j < ans.size(); j++)
    {
        cout << ans[j] << " ";
    }
    return 0;
}