#include<bits/stdc++.h>
using namespace std;


void print_primes(int N){
    vector<int> nums(N+1);
    for(int i=0;i<=N;i++){
        nums[i]=i;
    }
    vector<bool> marks(N+1,false);
    for(int i=2;i*i<=N;i++){
        if(!marks[i]){
            //marks[i]=true;
            for(int j=i*i;j<=N;j+=i){
                marks[j]=true;
            }
        }
    }
    for(int i=2;i<=N;i++){
        if(!marks[i]){
            cout<<nums[i]<<" ";
        }
    }
    cout<<endl;
}


int main(){
    int N=50;
    print_primes(N);
    return 0;
}