#include<bits/stdc++.h>
using namespace std;

int main(){
    vector<int> v={1,2,3};
    stack<int> st;
    st.push(-1);
    vector<int> ans={};
    for(int i=v.size()-1;i>=0;i--){
        if(st.top()>v[i]){
            ans.push_back(st.top());
            st.push(v[i]);
        }
        else{
            while(st.top()<=v[i] && st.top()>=0){
                st.pop();
            }
            if(st.top()>=v[i]){
                ans.push_back(st.top());
                st.push(v[i]);
            }
            else if(st.top()==-1){
                ans.push_back(-1);
                st.push(v[i]);
            }
        }
    }
    reverse(ans.begin(),ans.end());
    for(int i=0;i<ans.size();i++){
        cout<<ans[i]<<" ";
    }
    return 0;
}