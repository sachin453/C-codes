#include <bits/stdc++.h>
using namespace std;

int min_nom(int arr[], int i, int j, int dp[10][10])
{
    if (dp[i][j] != -1)
    {
        return dp[i][j];
    }
    if (i >= j)
    {
        return dp[i][j] = 0;
    }
    else if (j == i + 1)
    {
        return dp[i][j] = arr[i - 1] * arr[i] * arr[i + 1];
    }
    int ans = INT_MAX;
    int x = 0;
    for (int k = i; k < j; k++)
    {
        x = min_nom(arr, i, k, dp) + min_nom(arr, k + 1, j, dp) + arr[i - 1] * arr[k] * arr[j];
        if (x < ans)
        {
            ans = x;
        }
    }
    return dp[i][j] = ans;
}

int main()
{
    int dp[10][10];
    memset(dp, -1, sizeof(dp));
    int arr[] = {5, 4, 6, 7, 9, 11, 15};
    cout << min_nom(arr, 1, 6, dp)
    return 0;
}