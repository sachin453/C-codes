#include <iostream>
#include <vector>
using namespace std;

void print_vector(vector<int> V)
{
    cout << "{";
    for (int i = 0; i < V.size(); i++)
    {
        cout << " " << V[i];
    }
    cout << " }";
}

vector<int> func(vector<int> vect)
{
    vector<vector<int>> V;
    int j = 0;
    V.push_back({});
    int sum = 0;
    for (int i = 0; i < vect.size(); i++)
    {
        if (vect[i] >= 0)
        {
            V[j].push_back(vect[i]);
            sum += vect[i];
        }
        else
        {
            V[j].push_back(sum);
            V.push_back({});
            j++;
            sum = 0;
        }
        if (i == vect.size() - 1 && vect[vect.size() - 1] >= 0)
        { // if last element is + then subarray will end at it but becoz there is no next -ve element , the sum wont get added in place of last element, this condition is for that case
            V[j].push_back(sum);
        }
    }
    int max_sum_index = 0;
    int max_sum = 0;
    for (int i = 0; i < V.size(); i++)
    {
        if (V[i][V[i].size() - 1] > max_sum)
        { // finding the index of sub array having maximum sum
            max_sum = V[i][V[i].size() - 1];
            max_sum_index = i;
        }
    }
    V[max_sum_index].pop_back(); // remove the sum from sub array
    return V[max_sum_index];
}

int main()
{
    vector<int> parent_vector = {-6,5,9,3,-6,4,9,-1,100,5,9,-7,-27,45,71,-99,99,97};
    print_vector(func(parent_vector));
    return 0;
}