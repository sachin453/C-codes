#include<bits/stdc++.h>
using namespace std;


struct person{
    int balance;
    string key;
};



void transfer_money(int amount,person &sender,string my_key,person &reciever){
    if(sender.key!=my_key){
        cout<<"invalid_id_password"<<endl;
        return;
    }
    else if(sender.balance<amount){
        cout<<"insufficient_money"<<endl;
        return;
    }
    else{
        sender.balance-=amount;
        reciever.balance+=amount;
    }
    cout<<"now you have "<<sender.balance<<" left"<<endl;
    return ;
}








int main(){
    person sachin,ravi;
    sachin.balance=1400;
    sachin.key="jags";
    ravi.balance=120;
    ravi.key="1234g";


    transfer_money(12,ravi,"1234g",sachin);
    transfer_money(12,ravi,"1234g",sachin);
    transfer_money(12,ravi,"1234g",sachin);
    transfer_money(12,ravi,"1234g",sachin);
    return 0;
}