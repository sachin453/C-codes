#include<bits/stdc++.h>
using namespace std;



int func(string A,string B,int a,int b,vector<vector<int>> &dp){
    if(dp[a][b]!=-1){
        return dp[a][b];
    }
    if(a==A.size()){
        if(b==B.size()){
            return dp[a][b]= 1;
        }
        else{
            return dp[a][b]= 0;
        }
    }
    else if(b==B.size()){
        return dp[a][b]= 1;
    }
    else{
        if(A[a]==B[b]){
            int x=func(A,B,a+1,b+1,dp);
            int y=func(A,B,a+1,b,dp);
            return dp[a][b]= x+y;
        }
        else{
            return dp[a][b]= func(A,B,a+1,b,dp);
        }
    }
}





int main(){
    string A="rabbbit",B="rabbit";
    vector<vector<int>> dp(A.size()+1,vector<int> (B.size()+1,-1));
    int ans=func(A,B,0,0,dp);
    cout<<ans;
    return 0;
}