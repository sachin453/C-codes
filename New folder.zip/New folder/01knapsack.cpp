#include <bits/stdc++.h>
using namespace std;
#include<cstring>
int max(int a,int b){
    if(a>b){
        return a;
    }
    return b;
}

int max_profit(int wt[], int vl[], int W, int n,int dp[1000][1000])
{
    if (W == 0 || n == 0)
    {
        return 0;
    }
    if(dp[n][W]!=-1){
        return dp[n][W];
    }
    else{
        if(wt[n-1]<=W){
            return dp[n][W]=max(vl[n-1]+max_profit(wt,vl,W-wt[n-1],n-1,dp),max_profit(wt,vl,W,n-1,dp));
        }
        else{
            return dp[n][W]=max_profit(wt,vl,W,n-1,dp);
        }
    }
}

int main()
{
    static int dp[1000][1000];
    memset(dp,-1,sizeof(dp));
    int wgt[] = {1,3,4};
    int val[] = {2,5,8};
    int W = 5;
    cout<<max_profit(wgt,val,W,3,dp);
    return 0;
}