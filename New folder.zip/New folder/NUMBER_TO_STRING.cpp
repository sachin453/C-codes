#include<bits/stdc++.h>
using namespace std;


string func(string A){
    static string ans="";
    if(A.size()==0){
        return ans;
    }
    else if(A.size()<=2 && stoi(A)<=26){
        ans.push_back(char(stoi(A)+64));
        return ans;
    }
}


int main(){
    cout<<func("9")[0];
    return 0;
}