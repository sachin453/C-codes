#include<bits/stdc++.h>
using namespace std;

void init_code(){
	freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
}

#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
#define pb push_back
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}


int mul_in_range(int l,int r,int num){
    if(l%num==0){
        return l;
    }
    int x=num-l%num;
    if(x+l<=r){
        return x+l;
    }
    return -1;
}


void func(int l,int r,int n){
    vi ans(n);
    bool y=true;
    for(int i=n;i>=1;i--){
        ans[i-1]= ((l - 1) / i + 1) * i;
            if(ans[i-1]>=r){
                y=false;
                break;
            }
    }
    if(y){
        cout<<"YES"<<endl;
        print_vec(ans);
        return;
    }
    else{
        cout<<"NO"<<endl;
        return;
    }
}

int main() {
	init_code();
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        int n,l,r;
        cin>>n>>l>>r;
        func(l,r,n);
    }
	return 0;
}