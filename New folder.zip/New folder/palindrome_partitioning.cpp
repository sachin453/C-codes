#include<bits/stdc++.h>
using namespace std;

bool is_palindrome(string s,int i,int j){
    if(i>=j){
        return true;
    }
    else{
        if(s[i]==s[j]){
            return is_palindrome(s,i+1,j-1);
        }
        return false;
    }
}




int min_nof_partition(string s,int i,int j,int dp[20][20]){
    if(dp[i][j]!=-1){
        return dp[i][j];
    }
    if(i>=j){
        return dp[i][j]= 0;
    }
    if(is_palindrome(s,i,j)==true){
        return dp[i][j]= 0;
    }
    int ans=INT_MAX;
    for(int k=i;k<j;k++){
        ans=min(1+min_nof_partition(s,i,k,dp)+min_nof_partition(s,k+1,j, dp),ans);
    }
    return dp[i][j]= ans;
}


int main(){
    int dp[20][20];
    memset(dp,-1,sizeof(dp));
    string s="nitikxxxtttxxxk";
    int n=s.size();
    cout<<is_palindrome(s,0,n-1)<<"\n";
    cout<<min_nof_partition(s,0,n-1,dp);
    return 0;
}