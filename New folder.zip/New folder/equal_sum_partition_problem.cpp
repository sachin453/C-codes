#include<bits\stdc++.h>
using namespace std;

bool func(vector<int> v1,vector<int> v2,int n,int N,int sum1,int sum2){
    if(N==0 || N==1 || (sum1+sum2)%2!=0){
        return false;
    }
    if(n==1){
        if(sum1-v1[0]==sum2+v1[0]){
            return true;
        }
        else{
            return false;
        }
    }
    if(sum1==sum2 || sum1-v1[n-1]==sum2+v1[n-1]){
        return true;
    }
    else{
        vector<int> v3,v4;
        v3=v1;v4=v2;
        v3[n-1]=0;v4[n-1]=v1[n-1];
        return func(v1,v2,n-1,N,sum1,sum2) || func(v3,v4,n-1,N,sum1-v1[n-1],sum2+v1[n-1]);
    }
}

bool top_down(vector<int> V){
    int n=V.size();
    int sum=accumulate(V.begin(),V.end(),0);
    if(n==0 || n==1 || sum%2 !=0){
        return false;
    }
    sum=sum/2;
    bool dp[n][sum+1];
    memset(dp,false,sizeof(dp));
    for(int i=0;i<n;i++){
        for(int j=0;j<sum+1;j++){
            if(i==0 || V[i]==j){
                dp[i][j]=true;
            }
            else {
                if(V[i]>j){
                    dp[i][j]=dp[i-1][j];
                }
                else{
                    dp[i][j]=dp[i-1][j] || dp[i][j-V[i]];
                }
            }
        }
    }
    return dp[n-1][sum];
}



int main(){
    vector<int> v1={0,0,0,1,1,2,3,6,4,8,1,39,8,13};
    int n=v1.size();
    //n=7;
    vector<int> v2(n,0);
    int sum=accumulate(v1.begin(),v1.end(),0);
    cout<<func(v1,v2,n,n,sum,0)<< " haha " << top_down(v1);
    return 0;
}