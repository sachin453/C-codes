#include<bits/stdc++.h>
using namespace std;



vector<vector<int>> check_func(vector<int> v, int sum){
    vector<vector<int>> ans;
    sort(v.begin(),v.end());
    int n=v.size();
    unordered_map<int,int> m;
    for(int i=0;i<n;i++){
        m[v[i]]++;
    }
    for(int i=0;i<n;i++){
        int k=sum-v[i];
        if(m[k]!=0){
            vector<int> ans1(2,0);
            ans1[0]=v[i];
            ans1[1]=k;
            ans.push_back(ans1);
        }
    }

    return ans;
}

int main(){
    vector<int> v={-19,-15,-11,-8,-5,-3,-1,0,2,4,6,9,11,14,16,19,21};
    int sum=1;
    vector<vector<int>> V;
    V=check_func(v,sum);
    int N=V.size();
    for(int i=0;i<N/2;i++){
        cout<<V[i][0]<<" "<<V[i][1]<<"\n";
    }
    return 0;
}