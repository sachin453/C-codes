#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define vll vector<ll>
#define vi vector<int>
#define pb push_back
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}


void init_code(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
}

int main() {
	init_code();
    // your code goes here
    int T;
    cin>>T;
    while(T--){
        int N,M;
        cin>>N>>M;
        long long ans=0;
        int p=N,q=N;
        for(long long i=N;i<=2*N && i<=M;i++){
            int x;
            if(M%i==0){
                x=M;
            }
            else{
                x=M-M%i;
            }
            ans=max(ans,x-i);
            if(ans==x-i){
                p=x;
                q=i;
            }
        }
        cout<<p<<" "<<q<<endl;
    }
	return 0;
}