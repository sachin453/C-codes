#include<bits/stdc++.h>
using namespace std;

string lcs_lpss(string s1) // longest palidromic substring
{
    string s2=s1;
    reverse(s2.begin(),s2.end());
    int n1 = s1.size();
    int n2 = s2.size();
    int dp[n1 + 1][n2 + 1];
    int ans = 0;
    memset(dp, 0, sizeof(dp));
    int p=-1;int q=-1;
    for (int i = 0; i < n1 + 1; i++)
    {
        for (int j = 0; j < n2 + 1; j++)
        {
            if (i == 0 || j == 0)
            {
                dp[i][j] == 0;
            }
            else
            {
                if (s1[i - 1] == s2[j - 1])
                {
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                }
                else
                {
                    dp[i][j] = 0;
                }
            }
            if (dp[i][j] > ans)
            {
                ans = dp[i][j];
                p=i;q=j;
            }
        }
    }
    string s="";
    for(int i=ans;i>0;i--){
        s+=s1.substr(p-1-ans+i,1);
    }
    reverse(s.begin(),s.end());
    return s;
}


int main(){
    string s1="aacabdkacaa";
    cout<<lcs_lpss(s1);
    return 0;
}