#include <iostream>
#include<vector>
using namespace std;

int func(int A,int B,int N){
    vector<int> a(N),b(N),n(N);
    for(int i=N-1;i>=0;i--){
        a[i]=A%2;
        A=A/2;
        b[i]=B%2;
        B=B/2;
        n[i]=1;
    }
    int mis_match=-1;
    for(int i=0;i<N;i++){
        if(a[i]==1 && b[i]==1){
            n[i]=0;
        }
        else if(a[i]==0 && b[i]==0){
            n[i]=1;
        }
        else {
            if(mis_match==-1){
                if(a[i]==0){
                    n[i]=1;
                }
                else{
                    n[i]=0;
                }
                mis_match=0;
            }
            else{
                n[i]=a[i];
            }
        }
    }
    int X=0;
    for(int i=0;i<N;i++){
        X=X*2+n[i];
    }
    return X;
}


int main() {
	int T;
	cin>>T;
	while(T--){
	    int N,A,B;
	    cin>>N>>A>>B;
	    cout<<func(A,B,N)<<endl;
	}
	return 0;
}
