#include <bits/stdc++.h>
using namespace std;

string nos(int n)
{
    string s = "";
    int x = n > 0 ? 1 : -1;
    n = n * x;
    if (n == 0)
    {
        s = "0";
    }
    else if (n == 100)
    {
        s = "100";
    }
    else if (n > 0 && n < 10)
    {
        char c = (char)(48 + n);
        s.push_back(c);
    }
    else
    {
        char a = (char)(48 + n / 10);
        char b = (char)(48 + n % 10);
        s.push_back(a);
        s.push_back(b);
    }
    return x > 0 ? s : "-" + s;
}
string func(string s1, string s3)
{
    int i = 0;
    int j = 0;
    while (i < s1.size() && j < s3.size())
    {
        if (s3[j] != s1[i])
        {
            j++;
        }
        else
        {
            i++;
            s3.replace(j, 1, "");
        }
    }
    return s3;
}
string temp1(int i, int j)
{
    string s = "";
    if (i < 10)
    {
        int n = 48 + i;
        char c1 = (char)n;
        s.push_back(c1);
    }
    else
    {
        char c1 = (char)(48 + i % 10);
        char c2 = (char)(48 + i / 10);
        s.push_back(c2);
        s.push_back(c1);
    }
    s += "_";
    if (j < 10)
    {
        int n = 48 + j;
        char c1 = (char)n;
        s.push_back(c1);
    }
    else
    {
        char c1 = (char)(48 + j % 10);
        char c2 = (char)(48 + j / 10);
        s.push_back(c2);
        s.push_back(c1);
    }
    return s;
}

bool temp3(int n)
{
    while (n != 1)
    {
        if (n % 2 == 0)
        {
            n = n / 2;
        }
        else if (n % 3 == 0)
        {
            n = n / 3;
        }
        else if (n % 5 == 0)
        {
            n = n / 5;
        }
        else
        {
            return false;
        }
    }
    if (n != 1)
    {
        return false;
    }
    else
    {
        return true;
    }
}
int func1(int n)
{
    int n2 = 1;
    int n21 = n;
    while (n21 != 0)
    {
        n2 = n2 * 2;
        n21 = n21 / 2;
    }
    int n3 = 1;
    int n31 = n;
    while (n31 != 0)
    {
        n3 = n3 * 3;
        n31 = n31 / 3;
    }
    int n5 = 1;
    int n51 = n;
    while (n51 != 0)
    {
        n5 = n5 * 5;
        n51 = n51 / 5;
    }
    return min(n2, min(n3, n5));
}

string temp11(int i, int m, int n)
{
    string s = "";
    if (i < 10)
    {
        char c1 = (char)(i + 48);
        s.push_back(c1);
    }
    else if (i < 100)
    {
        char c1 = (char)(i % 10 + 48);
        s.push_back(c1);
        char c2 = (char)(i / 10 + 48);
        s.push_back(c2);
    }
    else
    {
        char c1 = (char)(i % 10 + 48);
        s.push_back(c1);
        char c2 = (char)((i / 10) % 10 + 48);
        s.push_back(c2);
        char c3 = (char)(i / 100 + 48);
        s.push_back(c3);
    }
    s.push_back('_');
    i = m;
    if (i < 10)
    {
        char c1 = (char)(i + 48);
        s.push_back(c1);
    }
    else if (i < 100)
    {
        char c1 = (char)(i % 10 + 48);
        s.push_back(c1);
        char c2 = (char)(i / 10 + 48);
        s.push_back(c2);
    }
    else
    {
        char c1 = (char)(i % 10 + 48);
        s.push_back(c1);
        char c2 = (char)((i / 10) % 10 + 48);
        s.push_back(c2);
        char c3 = (char)(i / 100 + 48);
        s.push_back(c3);
    }
    s.push_back('_');
    i = n;
    if (i < 10)
    {
        char c1 = (char)(i + 48);
        s.push_back(c1);
    }
    else if (i < 100)
    {
        char c1 = (char)(i % 10 + 48);
        s.push_back(c1);
        char c2 = (char)(i / 10 + 48);
        s.push_back(c2);
    }
    else
    {
        char c1 = (char)(i % 10 + 48);
        s.push_back(c1);
        char c2 = (char)((i / 10) % 10 + 48);
        s.push_back(c2);
        char c3 = (char)(i / 100 + 48);
        s.push_back(c3);
    }
    return s;
}

int func12(vector<int> v)
{
    int n = v.size();
    stack<int> st;
    st.push(-1);
    vector<int> ans_left, ans_right;
    for (int i = 0; i < n; i++)
    {
        if (st.top() != -1)
        {
            if (v[st.top()] < v[i])
            {
                ans_left.push_back(st.top());
                st.push(i);
            }
            else
            {
                while (st.top() >= 0)
                {
                    if (v[st.top()] >= v[i])
                    {
                        st.pop();
                    }
                    else
                    {
                        break;
                    }
                }
                if (st.top() == -1)
                {
                    ans_left.push_back(-1);
                    st.push(i);
                }
                else if (v[st.top()] < v[i])
                {
                    ans_left.push_back(st.top());
                    st.push(i);
                }
            }
        }
        else
        {
            ans_left.push_back(-1);
            st.push(i);
        }
    }

    st.empty();
    st.push(-1);

    for (int i = n - 1; i >= 0; i--)
    {
        if (st.top() != -1)
        {
            if (v[st.top()] < v[i])
            {
                ans_right.push_back(st.top());
                st.push(i);
            }
            else
            {
                while (st.top() >= 0)
                {
                    if (v[st.top()] >= v[i])
                    {
                        st.pop();
                    }
                    else
                    {
                        break;
                    }
                }
                if (st.top() == -1)
                {
                    ans_right.push_back(-1);
                    st.push(i);
                }
                else if (v[st.top()] < v[i])
                {
                    ans_right.push_back(st.top());
                    st.push(i);
                }
            }
        }
        else
        {
            ans_right.push_back(-1);
            st.push(i);
        }
    }
    reverse(ans_right.begin(), ans_right.end());

    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        if (ans_right[i] == -1)
        {
            ans_right[i] = n;
        }
        ans = max(ans, v[i] * (ans_right[i] - ans_left[i] - 1));
    }

    return ans;
}

int main()
{
    set<int> s= {4,3,2};
    cout<< *s.begin();
    return 0;
}