#include<bits/stdc++.h>
using namespace std;


int func(vector<int> v,int sum){
    int ans=0;
    int n=v.size();
    if(sum==0){
        return 1;
    }
    if(n==0){
        return 0;
    }
    int dp[n][sum+1];
    memset(dp,0,sizeof(dp));
    for(int i=0;i<n;i++){
        for(int j=0;j<sum+1;j++){
            if(i==0 && j!=0){
                if(v[i]==j){
                    dp[i][j]=1;
                }
            }
            else if(j==0){
                dp[i][j]=1;
            }
            else{
                if(v[i]>j){
                    dp[i][j]=dp[i-1][j];
                }
                else{
                    dp[i][j]=dp[i-1][j]+dp[i-1][j-v[i]];
                }
            }
        }
    }

    return dp[n-1][sum];
}




int main(){

    vector<int> V={1,2,3,4,5,6,9};
    int sum=4;
    cout<<func(V,sum);
    return 0;
}