#include<bits/stdc++.h>
using namespace std;
void print_vec(vector<int> v)
{ // prints the given vector
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}
int func(vector<vector<int>> g,vector<bool> visited,int node){
    if(visited[node])return 0;
    visited[node]=true;
    int mark=0;
    int ans=0;
    for(int i=0;i<g[node].size();i++){
        if(!visited[g[node][i]]){
            mark=1;
            ans=max(ans,1+func(g,visited,g[node][i]));
        }
    }
    if(mark==1)return ans;
    return 0;
}
void tree_height(vector<vector<int>> g){
    int nodes=g.size();
    int height;
    vector<bool> visited(nodes,false);
    height=func(g,visited,0);
    cout<<"Height of tree is "<<height;
}

void func1(vector<vector<int>> g,vector<bool> visited,int node,vector<int> &depth,int d){
    if(visited[node])return;
    visited[node]=true;
    int ans=0;
    for(int i=0;i<g[node].size();i++){
        if(!visited[g[node][i]]){
            depth[g[node][i]]=d+1;
            func1(g,visited,g[node][i],depth,d+1);
        }
    }
}

void tree_depth(vector<vector<int>> g){
    int nodes=g.size();
    vector<int> depth(nodes,0);
    vector<bool> visited(nodes,false);
    func1(g,visited,0,depth,0);
    cout<<"depth of the nodes is : "<<endl;
    for(int i=0;i<nodes;i++){
        cout<<i<<"->"<<depth[i]<<endl;
    }
}




int main(){
    init_code();
    int nodes,edges;
    cin>>nodes>>edges;
    vector<vector<int>> g(nodes);
    for(int i=0;i<edges;i++){
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    tree_height(g);
    tree_depth(g);
    return 0;
}