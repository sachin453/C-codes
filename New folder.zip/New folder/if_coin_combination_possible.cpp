#include<iostream>
using namespace std;

bool iccp(int c[],int sum,int n){
    static int arr[3]={0,0,0};
    if(n==0){
        return false;
    }
    else if(n==1 || sum==0){
        if(sum%c[n-1]==0){
            return true;
        }
        else {
            return false;
        }
    }
    else{
        if(c[n-1]>sum){
            return iccp(c,sum,n-1);
        }
        else{
            return (iccp(c,sum,n-1) || iccp(c,sum-c[n-1],n));
        }
    }
    return false;
}


int main(){
    int coins[]={8,17,29};
    int n;
    cin>>n;
    if(iccp(coins,n,3)==true){
        cout<<"true";
    }
    else{
        cout<<"false";
    }
    return 0;
}