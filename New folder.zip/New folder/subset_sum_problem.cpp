#include<bits/stdc++.h>
using namespace std;


bool if_subset_present(int arr[],int n,int sum,int original_sum){
    if(sum==0){
        return true;
    }
    else if(n==0){
        if(sum==0){
            return true;
        }
        else{
            return false;
        }
    }
    else if(n==1){
        if(arr[n-1]==sum){
            return true;
        }
        else {
            return false;
        }
    }
    else{
        if(arr[n-1]>sum){
            return if_subset_present(arr,n-1,original_sum,original_sum);
        }
        else if(arr[n-1]==sum){
            return true;
        }
        else {
            return (if_subset_present(arr,n-1,sum-arr[n-1],original_sum)||if_subset_present(arr,n-1,original_sum,original_sum));
        }
    }
    //return false;
}


bool using_topdown(int arr[],int n,int sum){
    bool dp[100][100];
    memset(dp,false,sizeof(dp));
    for(int i=0;i<n+1;i++){
        for(int j=0;j<sum+1;j++){
            if(i==0){
                dp[i][j]=false;
            }
            else if(j==0){
                dp[i][j]=true;
            }
            else{
                if(arr[i-1]>j){
                    dp[i][j]=dp[i-1][j];
                }
                else if(arr[i-1]==j){
                    dp[i][j]=true;
                }
                else{
                    dp[i][j]=(dp[i-1][j-arr[i-1]] || dp[i-1][j]);
                }
            }
        }
    }
    return dp[n][sum];
}


int main(){
    int arr[]={2,3,7,8,10};
    int sum;
    cin>>sum;
    cout<<if_subset_present(arr,5,sum,sum)<<" "<<using_topdown(arr,5,sum);
    return 0;
}