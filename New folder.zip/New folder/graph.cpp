#include <bits/stdc++.h>
using namespace std;
void print_vec(vector<int> v)
{ // prints the given vector
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}
void dfs(vector<vector<int>> g, int vertex, vector<bool> &visited)
{
    visited[vertex] = true;
    for (int i = 0; i < g[vertex].size(); i++)
    {
        if (visited[g[vertex][i]])
        {
            continue;
        }
        dfs(g, g[vertex][i], visited);
    }
    cout << vertex << " ";
}
void store_connected_nodes(vector<vector<int>> g, int vertex, vector<bool> &visited, vector<int> &nodes)
{
    visited[vertex] = true;
    for (int i = 0; i < g[vertex].size(); i++)
    {
        if (visited[g[vertex][i]])
        {
            continue;
        }
        store_connected_nodes(g, g[vertex][i], visited, nodes);
    }
    nodes.push_back(vertex);
}
int count_component(vector<vector<int>> g, vector<vector<int>> &con_comp)
{
    int no_of_nodes = g.size();
    vector<bool> visited(no_of_nodes, false);
    int count = 0;
    for (int i = 0; i < no_of_nodes; i++)
    {
        if (!visited[i])
        {
            vector<int> v;
            count++;
            store_connected_nodes(g, i, visited, v);
            con_comp.push_back(v);
        }
    }
    return count;
}
void cycle_finder(vector<vector<int>> g, int vertex, vector<bool> &visited, int parent, bool &ans)
{
    visited[vertex] = true;
    for (int i = 0; i < g[vertex].size(); i++)
    {
        int neig = g[vertex][i];
        if (visited[neig] && neig != parent)
        {
            ans = true;
        }
        if (!visited[neig])
        {
            cycle_finder(g, neig, visited, vertex, ans);
        }
    }
    // cout<<vertex<<" ";
}
void final_cycle_finder(vector<vector<int>> g)
{
    int no_of_vertex = g.size();
    vector<bool> visited1(no_of_vertex, false);
    bool ans = false;
    for (int i = 0; i < no_of_vertex; i++)
    {
        if (!visited1[i] && g[i].size() != 0)
        {
            cycle_finder(g, i, visited1, g[i][0], ans);
        }
    }
    cout << "if_cycle_present = " << ans << endl;
}

int main()
{
    init_code();
    int no_of_vertex, no_of_edges;
    cin >> no_of_vertex >> no_of_edges;
    vector<vector<int>> g(no_of_vertex);
    for (int i = 0; i < no_of_edges; i++)
    {
        int x, y;
        cin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    vector<bool> visited(no_of_vertex, false);
    dfs(g, 0, visited);
    vector<vector<int>> con_comp;
    cout << "no_of_connected_components = " << count_component(g, con_comp) << endl;
    for (int i = 0; i < con_comp.size(); i++)
    {
        print_vec(con_comp[i]);
    }
    final_cycle_finder(g);
    return 0;
}