#include <iostream>
#include<vector>
using namespace std;

int bitwise_xor(int a,int b){
    vector<int> as,bs,cs;
    while(a!=0 || b!=0){
        as.push_back(a%2);
        a=a/2;
        bs.push_back(b%2);
        b=b/2;
    }
    for(int i=0;i<as.size();i++){
        if(as[i]+bs[i]==1){
            cs.push_back(1);
        }
        else{
            cs.push_back(0);
        }
    }
    int ans=0;
    for(int i=cs.size()-1;i>=0;i--){
        ans=2*ans+cs[i];
    }
    return ans;
}


int main() {
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vector<int> nums(n);
        for(int i=0;i<n;i++){
            cin>>nums[i];
        }
        vector<int> left(n),right(n);
        for(int i=0;i<n;i++){
            if(i==0){
                left[0]=nums[0];
            }
            else{
                left[i]=bitwise_xor(left[i-1],nums[i]);
            }
            int j=n-1-i;
            if(j==n-1){
                right[n-1]=nums[n-1];
            }
            else{
                right[j]=bitwise_xor(right[j+1],nums[j]);
            }
        }
        int ans=-1;
        for(int i=0;i<n;i++){
            if(i==0){
                if(right[i+1]==nums[i]){
                    ans=nums[i];
                    break;
                }
            }
            else if(i==n-1){
                if(left[i-1]==nums[i]){
                    ans=nums[i];
                    break;
                }
            }
            else{
                if(bitwise_xor(left[i-1],right[i+1])==nums[i]){
                    ans=nums[i];
                    break;
                }
            }
        }
        
        cout<<ans;
        cout<<endl;
    }
	return 0;
}

