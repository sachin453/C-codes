#include <iostream>
#include<vector>
using namespace std;




int main() {
    int t;
    cin>>t;
    while(t--){
        int n,k;
        cin>>n>>k;
        vector<int> piles(n);
        for(int i=0;i<n;i++){
            cin>>piles[i];
        }
        int orig_count=0;
        for(int i=0;i<n;i++){
            if(i!=0 && i!=n-1){
                if(piles[i]>(piles[i-1]+piles[i+1])){
                    orig_count++;
                }
            }
        }
        if(k!=1){
            cout<<orig_count<<endl;
        }
        else{
            if(n%2==0){
                cout<<n/2-1<<endl;
            }
            else{
                cout<<n/2<<endl;
            }
        }
    }
	return 0;
}

