#include <bits/stdc++.h>
using namespace std;

int func(string A, string B, int a, int b, vector<vector<int>> &dp)
{
    if (a >= A.size())
    {
        return B.size() - b;
    }
    else if (b >= B.size())
    {
        return A.size() - a;
    }
    if(dp[a][b]!=-1){
        return dp[a][b];
    }
    if (A[a] == B[b])
    {
        return dp[a][b]= func(A, B, a + 1, b + 1, dp);
    }
    else
    {
        int x = 1 + func(A, B, a + 1, b + 1, dp);
        int y = 1 + func(A, B, a + 1, b, dp);
        int z = 1 + func(A, B, a, b + 1, dp);
        return dp[a][b]= min(x, min(y, z));
    }
    return 0;
}

int main()
{
    string A = "chinspcx", B = "chinsacx";
    vector<vector<int>> dp(A.size(), vector<int>(B.size(), -1));
    int ans = func(A, B, 0, 0, dp);
    cout << ans << endl;
    return 0;
}