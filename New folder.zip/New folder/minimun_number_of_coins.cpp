#include<bits/stdc++.h>
using namespace std;

int min(int a,int b){
    return a>b?b:a;
}

int minimun_no_of_coins(int coins[],int n,int sum){
    if(n==0 || sum==0){
        return 0;
    }
    else if(n==1){
        if(sum%coins[n-1]==0){
            return sum/coins[n-1];
        }
        else{
            return 10000;
        }
    }
    else{
        if(coins[n-1]>sum){
            return minimun_no_of_coins(coins,n-1,sum);
        }
        else{
            return min(1+minimun_no_of_coins(coins,n,sum-coins[n-1]),minimun_no_of_coins(coins,n-1,sum));
        }
    }
    return 0;
}

int main(){
    int coins[]={2,3,8,9};
    int sum=13;
    cout<<minimun_no_of_coins(coins,4,sum);
    return 0;
}