#include <iostream>
#include<bits/stdc++.h>
using namespace std;



string findDiff(string str1, string str2)
{
    string str = "";
 
    // Calculate length of both string
    int n1 = str1.length(), n2 = str2.length();
 
    // Reverse both of strings
    reverse(str1.begin(), str1.end());
    reverse(str2.begin(), str2.end());
 
    int carry = 0;
 
    // Run loop till small string length
    // and subtract digit of str1 to str2
    for (int i = 0; i < n2; i++) {
        // Do school mathematics, compute difference of
        // current digits
 
        int sub
            = ((str1[i] - '0') - (str2[i] - '0') - carry);
 
        // If subtraction is less than zero
        // we add then we add 10 into sub and
        // take carry as 1 for calculating next step
        if (sub < 0) {
            sub = sub + 10;
            carry = 1;
        }
        else
            carry = 0;
 
        str.push_back(sub + '0');
    }
 
    // subtract remaining digits of larger number
    for (int i = n2; i < n1; i++) {
        int sub = ((str1[i] - '0') - carry);
 
        // if the sub value is -ve, then make it positive
        if (sub < 0) {
            sub = sub + 10;
            carry = 1;
        }
        else
            carry = 0;
 
        str.push_back(sub + '0');
    }
 
    // reverse resultant string
    reverse(str.begin(), str.end());
 
    return str;
}



string func(string s,int len){
    string ans,pr;
    if(s[0]!='9'){
        for(int i=0;i<len;i++){
            pr.push_back('9');
        }
    }
    else{
        for(int i=0;i<=len;i++){
            pr.push_back('1');
        }
    }
    ans=findDiff(pr,s);
    if(ans[0]=='0'){
        ans=ans.substr(1,ans.size()-1);
    }
    return ans;
}



int main() {
	int t;
	cin>>t;
	while(t--){
	    int len;
	    cin>>len;
	    string s;
	    cin>>s;
	    cout<<func(s,len)<<endl;
	}
	return 0;
}
