#include<iostream>
using namespace std;

struct trinary_node{
    int data;
    trinary_node* left;
    trinary_node* right;
    trinary_node* middle;
};

trinary_node* get_new_trinary_node(int data){
    trinary_node* temp=new ( trinary_node);
    temp->data=data;
    temp->left=NULL;
    temp->middle=NULL;
    temp->right=NULL;
    return temp;
}


trinary_node* insart(trinary_node* &rut,int data){
    if(rut==NULL){
        rut=get_new_trinary_node(data);
    }
    else if(rut->left==NULL){
        insart(rut->left,data);
    }
    else if(rut->middle==NULL){
        insart(rut->middle,data);
    }
    else if(rut->right==NULL){
        insart(rut->right,data);
    }
    else{
        insart(rut->middle,data);
    }
    return rut;
}

bool check_number(trinary_node* rut,int data){
    if(rut->data==data || rut->left->data==data || rut->right->data==data){
        return true;
    }
    else{
        return check_number(rut->middle,data);
    }
    return false;
}

int main(){
    trinary_node* root=new (trinary_node);
    root=NULL;
    insart(root,6);
    for(int i=0;i<100;i++){
        insart(root,i*i);
    }
    cout<<root->middle->middle->middle->right->data;
    cout<<endl<<check_number(root,99*99);
    return 0;
}