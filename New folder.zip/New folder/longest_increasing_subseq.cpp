#include<bits/stdc++.h>
using namespace std;

int func(vector<int> nums){
    if(nums.size()==0){
        return 0;
    }
    int ans=0;
    int dp1[nums.size()],dp2[nums.size()];
    dp1[0]=1;dp2[nums.size()-1]=1;
    for(int i=1;i<nums.size();i++){
        int templ=0;
        for(int j=0;j<i;j++){
            if(nums[j]<nums[i]){
                templ=max(templ,dp1[j]);
            }
        }
        dp1[i]=1+templ;

        int k=nums.size()-i-1;
        int tempr=0;
        for(int l=nums.size()-1;l>k;l--){
            if(nums[l]<nums[k]){
                tempr=max(tempr,dp2[l]);
            }
        }
        dp2[k]=tempr+1;
    }
    for(int i=0;i<nums.size();i++){
        ans=max(ans,dp1[i]+dp2[i]-1);
    }
    return ans;
}





int main(){
    vector<int> nums={1, 11, 2, 10, 4, 5, 2, 1};
    int ans=func(nums);
    cout<<ans;
    return 0;
}