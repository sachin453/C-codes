#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}




int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vi marks(n+1);
        map<int,int> mp1,mp2;
        int ans=true;
        for(int i=1;i<=n;i++){
            int ai,bi;
            cin>>ai>>bi;
            if(ai==bi){
                ans=false;
            }
            if(mp1[ai]==0 && mp1[bi]==0 && mp2[ai]==0 && mp2[bi]==0){
                marks[i]=1;
                mp1[ai]=1;
                mp1[bi]=1;
            }
            else if(mp1[ai]!=0 || mp1[bi]!=0){
                if(mp2[ai]==0 && mp2[bi]==0){
                    marks[i]=2;
                    mp2[ai]=1;
                    mp2[bi]=1;
                }
                else{
                    ans=false;
                }
            }
            else if(mp2[ai]!=0 || mp2[bi]!=0){
                if(mp1[ai]==0 && mp1[bi]==0){
                    marks[i]=1;
                    mp1[ai]=1;
                    mp1[bi]=1;
                }
                else{
                    ans=false;
                }
            }
        }
        if(ans){
            cout<<"YES"<<endl;
        }
        else{
            cout<<"NO"<<endl;
        }
    }
	return 0;
}
