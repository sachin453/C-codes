#include<bits/stdc++.h> 
using namespace std;

int func(vector<int> prices){
    if(prices.size()<2){
        return 0;
    }
    int n=prices.size();
    int total_profit=0;
    int last_min_pick=prices[0];
    for(int i=1;i<prices.size();i++){
        if(prices[i]>last_min_pick){
            total_profit+=prices[i]-last_min_pick;
            last_min_pick=prices[i];
        }
        else{
            last_min_pick=prices[i];
        }
    }
    return total_profit;
}





int main(){
    vector<int> prices={5,2,1,20};
    int n=prices.size();
    int ans;
    if(n<2){
        return ans=0;
    }
    int dp[n];
    for(int i=n-1;i>=0;i--){
        if(i==n-1){
            dp[i]=0;
        }
        else{
            int temp=0,ans=dp[i+1];
            for(int j=i+1;j<n;j++){
                if(prices[j]>prices[i]){
                    temp=prices[j]-prices[i]+dp[j];
                }
                ans=max(ans,temp);
            }
            dp[i]=ans;
        }
    }
    ans= dp[0];
    cout<<ans<<endl;
    cout<<func(prices);
    return 0;
}