#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}




int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        int n,m;
        cin>>n>>m;
        n=n/2;
        m=m/2;
        int dp[n][m];
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                if(i%2==0){
                    if(j%2==0){
                        dp[i][j]=1;
                    }
                    else{
                        dp[i][j]=0;
                    }
                }
                if(i%2!=0){
                    if(j%2==0){
                        dp[i][j]=0;
                    }
                    else{
                        dp[i][j]=1;
                    }
                }
            }
        }
        int fdp[2*n][2*m];
        for(int i=0;i<2*n;i+=2){
            for(int j=0;j<2*m;j+=2){
                if(dp[i/2][j/2]==0){
                    fdp[i][j]=0;
                    fdp[i+1][j]=1;
                    fdp[i][j+1]=1;
                    fdp[i+1][j+1]=0;
                }
                else{
                    fdp[i][j]=1;
                    fdp[i+1][j]=0;
                    fdp[i][j+1]=0;
                    fdp[i+1][j+1]=1;
                }
            }
        }
        for(int i=0;i<n*2;i++){
            for(int j=0;j<m*2;j++){
                cout<<fdp[i][j]<<" ";
            }
            cout<<endl;
        }
    }
	return 0;
}
