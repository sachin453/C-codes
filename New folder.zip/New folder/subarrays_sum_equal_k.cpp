#include <bits/stdc++.h>
using namespace std;

int func(vector<int> row, int target)
{
    int m = row.size();
    vector<int> sums(m);
    sums[0] = row[0];
    for (int i = 1; i < m; i++)
    {
        sums[i] = row[i] + sums[i - 1];
    }
    map<int, int> mp;
    mp[0] = 1;
    int count = 0;
    for (int i = 0; i < m; i++)
    {
        int temp = sums[i] - target;
        count += mp[temp];
        mp[sums[i]]++;
    }
    return count;
}



int solv(vector<vector<int>> A)
{
    int m = A.size();
    int n = A[0].size();
    vector<vector<int>> dp(m, vector<int>(n));
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i == 0)
            {
                dp[i][j] = A[i][j];
            }
            else
            {
                dp[i][j] = A[i][j] + dp[i - 1][j];
            }
        }
    }
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = i; j < n; j++)
        {
            vector<int> row(m,0);
            for (int k = 0; k < m; k++)
            {
                row[k] = dp[j][k] - dp[i][k] + A[i][k];
            }
            int x=func(row,0);
            count+=x;
        }
    }
    return count;
}



int main()
{
    vector<vector<int>> nums ={{1,-1},{-1,1}}; 
    int target = 1;
    cout << solv(nums);
    return 0;
}