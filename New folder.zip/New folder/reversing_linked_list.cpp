#include<bits/stdc++.h>
using namespace std;

struct node{
    int val;
    node* next;
};


node* create_node(int n){
    node* nd = new node();
    nd->val = n;
    nd->next = NULL;
    return nd;
}

void add_node(node* l,int n){
    if(l==NULL){
        l = create_node(n);
        return ;
    }
    else if(l->next == NULL){
        l->next  = create_node(n);
        return;
    }
    else{
        add_node(l->next,n);
    }
}

void print_linked_list(node* l){
    while(l!=NULL){
        cout<<l->val<<"->";
        l=l->next;
    }
    return ;
}


node* invert_linked_list(node* l,int n,node* le){
    if((l==NULL || l->next==NULL)){
        return l;
    }
    else {
        if(n==0){
            node* l1=l->next;
            l->next=NULL;
            le=l;
            n++;
            return invert_linked_list(l1,n,le);
        }
        else{
            node* l1=l->next;
            l->next=le;
            le=l;
            n++;
            return invert_linked_list(l1,n,le);
        }

    }
}





int main(){
    node* root = create_node(6);
    add_node(root,7);
    add_node(root,6);
    add_node(root,8);
    add_node(root,1);
    add_node(root,17);
    add_node(root,21);
    print_linked_list(invert_linked_list(root,0,root));
    return 0;
}