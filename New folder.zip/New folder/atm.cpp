#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}




vi ngtr(vi arr){
    int n=arr.size();
    stack<int> st;
    st.push(-1);
    vi ind;
    for(int i=n-1;i>=0;i--){
        if(st.top()==-1){
            ind.push_back(-1);
            st.push(i);
        }
        else{
            if(arr[i]<=arr[st.top()]){
                ind.push_back(st.top());
                st.push(i);
            }
            else{
                while(st.top()!=-1 && arr[st.top()]<arr[i]){
                    st.pop();
                }
                if(st.top()==-1){
                    ind.push_back(-1);
                    st.push(i);
                }
                else{
                    ind.push_back(st.top());
                    st.push(i);
                }
            }
        }
    }
    reverse(ind.begin(),ind.end());
    return ind;
}

vi ngtl(vi arr){
    int n=arr.size();
    stack<int> st;
    st.push(-1);
    vi ind;
    for(int i=0;i<n;i++){
        if(st.top()==-1){
            ind.push_back(-1);
            st.push(i);
        }
        else{
            if(arr[i]<=arr[st.top()]){
                ind.push_back(st.top());
                st.push(i);
            }
            else{
                while(st.top()!=-1 && arr[st.top()]<arr[i]){
                    st.pop();
                }
                if(st.top()==-1){
                    ind.push_back(-1);
                    st.push(i);
                }
                else{
                    ind.push_back(st.top());
                    st.push(i);
                }
            }
        }
    }
    //reverse(ind.begin(),ind.end());
    return ind;
}


int func1(vi ngtr,vi arr,int t,int s){
    if(t<=s){
        return 0;
    }
    if(ngtr[s]<=t && ngtr[s]!=-1){
        return func1(ngtr,arr,t,ngtr[s]);
    }
    else{
        return arr[s]-arr[s+1]+func1(ngtr,arr,t,s+1);
    }
}
int func2(vi ngtl,vi arr,int t,int s){
    if(t>=s){
        return 0;
    }
    if(ngtl[s]>=t && ngtl[s]!=-1){
        return func2(ngtl,arr,t,ngtl[s]);
    }
    else{
        return arr[s]-arr[s-1]+func2(ngtl,arr,t,s-1);
    }
}



int main() {
    // your code goes here
    int n,m;
    cin>>n>>m;
    vi heights=scan_vec(n);
    vector<long long > forward_sum(n),backward_sum(n);
    forward_sum[0]=0;
    backward_sum[n-1]=0;
    for(int i=1;i<n;i++){
        if(heights[i]<heights[i-1]){
            forward_sum[i]=forward_sum[i-1]+heights[i]-heights[i-1];
        }
        else{
            forward_sum[i]=forward_sum[i-1];
        }
        int j=n-1-i;
        if(heights[j]<heights[j+1]){
            backward_sum[j]=backward_sum[j+1]+heights[j+1]-heights[j];
        }
        else{
            backward_sum[j]=backward_sum[j+1];
        }
    }
    for(int i=0;i<m;i++){
        int s,t;
        cin>>s>>t;
        s--;t--;
        if(s==t){
            cout<<0<<endl;
        }
        else if(s<t){
            cout<<-forward_sum[t]+forward_sum[s]<<endl;
        }
        else{
            cout<<backward_sum[t]-backward_sum[s]<<endl;
        }
    }
	return 0;
}
