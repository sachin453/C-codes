#include <iostream>
#include <vector>
using namespace std;
string temp(string s, int n)
{
    string s1 = "";
    if (n <= 9)
    {
        int n1 = n + 48;
        char c1 = (char)n1;
        s1.push_back(c1);
    }
    else if (n <= 99)
    {
        int n1 = n % 10 +48;
        int n2 = n / 10+48;
        char c2 = (char)n2;
        char c1 = (char)n1;
        s.push_back(c2);
        s.push_back(c1);
    }
    else
    {
        int n1 = n % 10+48;
        int n2 = (n / 10) % 10+48;
        int n3 = (n / 100)+48;
        char c1 = (char)n1;
        char c2 = (char)n2;
        char c3 = (char)n3;
        s.push_back(c3);
        s.push_back(c2);
        s.push_back(c1);
    }
    s1 += "_" + s;
    return s1;
}

int main()
{
    cout << temp("sach", 67);
    return 0;
}