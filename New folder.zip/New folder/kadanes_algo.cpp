#include<bits/stdc++.h>
using namespace std;

int kadane_algo(vector<int> v){   // maximum sum subarray
    int n=v.size();
    int ans=INT_MIN;
    int temp=0;
    for(int i=0;i<n;i++){
        temp+=v[i];
        if(temp<0){
            temp=0;
        }
        ans=max(ans,temp);
    }
    return ans;
}


int max_sum_rectangle(vector<vector<int>> V){
    int m=V.size();
    int n=V[0].size();
    int ans=INT_MIN;
    for(int i=0;i<m;i++){
        vector<int> v(n,0);
        for(int j=i;j<m;j++){
            for(int k=0;k<n;k++){
                v[k]+=V[j][k];
            }
            ans=max(ans,kadane_algo(v));
        }
    }
    return ans;
}


int kadane2(vector<int> v,int p){
    int n=v.size();
    int ans_min=0;
    int temp_min=0;
    for(int i=0;i<n;i++){
        temp_min+=v[i];
        if(temp_min>0){
            temp_min=0;
        }
        ans_min=min(ans_min,temp_min);
    }
    int ans=ans_min;
    int temp=0;
    for(int i=0;i<n;i++){
        temp+=v[i];
        if(temp<ans){
            temp=0;
        }
        if(temp<=p){
            ans=max(ans,temp);
        }
    }
    return ans;
}





int main(){
    vector<vector<int>> v={{2,1,-3,-4,5},{0,6,3,4,1},{2,-2,-1,4,-5},{-3,3,1,0,3}};
    //cout<<max_sum_rectangle(v);
    cout<<kadane2({-4,2,5,-8},6);
    return 0;
}