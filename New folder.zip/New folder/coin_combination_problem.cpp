#include<bits/stdc++.h>
using namespace std;

int number_of_ways(int coins[],int total,int n,int dp[100][100]){
    if(dp[total][n]!=-1){
        return dp[total][n];
    }
    if(n==0){
        return 0;
    }
    
    else if(n==1 || total==0){
        if(total%coins[0]==0){
            return 1;
        }
    }
    else{
        if(coins[n-1]>total){
            return dp[total][n-1]= number_of_ways(coins,total,n-1,dp);
        }
        else{
            dp[total-coins[n-1]][n]= number_of_ways(coins,total-coins[n-1],n,dp);
            dp[total][n-1]= number_of_ways(coins,total,n-1,dp);
            return dp[total-coins[n-1]][n]+dp[total][n-1];
        }
    }
    return 0;
}


int main(){
    int V[]={1,2,3};
    int dp[100][100];
    memset(dp,-1,sizeof(dp));
    int total=6;
    cout<< number_of_ways(V,total,3,dp);
    return 0;
}
