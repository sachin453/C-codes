#include<bits/stdc++.h>
using namespace std;
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}
void print_vec(vector<int> v)
{ // prints the given vector
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

void dfs(vector<vector<int>> g,int node,int par,vector<int> &depth){
    for(int child:g[node]){
        if(child==par)continue;
        depth[child]=depth[node]+1;
        dfs(g,child,node,depth);
    }
}
void diameter_of_tree(vector<vector<int>> g){
    vector<int> depth(g.size());
    dfs(g,0,-1,depth);
    int max_depth=-1;
    int ind;
    for(int i=0;i<g.size();i++){
        if(depth[i]>max_depth){
            max_depth=depth[i];
            ind=i;
        }
    }
    vector<int> depth_d(g.size());
    dfs(g,ind,-1,depth_d);
    max_depth=-1;
    for(int x:depth_d){
        max_depth=max(x,max_depth);
    }
    cout<<max_depth<<endl;
}


int main(){
    init_code();
    int nodes,edges;
    cin>>nodes>>edges;
    vector<vector<int>> g(nodes);
    for(int i=0;i<edges;i++){
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    diameter_of_tree(g);
    return 0; 
}