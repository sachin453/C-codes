#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define vll vector<ll>
#define vi vector<int>
#define pb push_back
using namespace std;
int max(int a, int b)
{ // max of two ints
    return a > b ? a : b;
}
int min(int a, int b)
{ // min of two ints
    return a > b ? b : a;
}
vi scan_vec(int n)
{ // scan and return a vector of length n
    vi v(n);
    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    return v;
}
void print_vec(vi v)
{ // prints the given vector
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}
vector<int> get_vec_range(int a, int b)
{                    // returns a vector containing intergers in range [a,b]
    vector<int> ans; // in increasing order
    for (int i = a; i <= b; i++)
    {
        ans.push_back(i);
    }
    return ans;
}
vi smaller_or_equal_in_left(vi arr)
{
    int n = arr.size();
    vi ans;
    stack<int> st;
    st.push(-1);
    for (int i = 0; i < n; i++)
    {
        if (st.top() != -1)
        {
            if (arr[st.top()] < arr[i])
            {
                ans.pb(st.top());
                st.push(i);
            }
            else
            {
                while (st.top() != -1 && arr[st.top()] >= arr[i])
                {
                    st.pop();
                }
                if (st.top() == -1)
                {
                    ans.pb(-1);
                    st.push(i);
                }
                else
                {
                    ans.pb(st.top());
                    st.push(i);
                }
            }
        }
        else
        {
            ans.pb(-1);
            st.push(i);
        }
    }
    return ans;
}
vi smaller_or_equal_in_right(vi arr)
{
    int n = arr.size();
    vi ans;
    stack<int> st;
    st.push(-1);
    for (int i = n - 1; i >= 0; i--)
    {
        if (st.top() != -1)
        {
            if (arr[st.top()] < arr[i])
            {
                ans.pb(st.top());
                st.push(i);
            }
            else
            {
                while (st.top() != -1 && arr[st.top()] >= arr[i])
                {
                    st.pop();
                }
                ans.pb(st.top());
                st.push(i);
            }
        }
        else
        {
            ans.pb(st.top());
            st.push(i);
        }
    }
    reverse(ans.begin(), ans.end());
    return ans;
}

void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}

int main()
{
    init_code();
    // your code goes here
    int m, n;
    cin >> m >> n;
    vector<vector<int>> v;
    for (int i = 0; i < m; i++)
    {
        vi v1 = scan_vec(n);
        v.pb(v1);
    }
    vector<vi> dp = v;
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (v[i][j] != 0 && i != 0)
            {
                dp[i][j] = dp[i - 1][j] + 1;
            }
        }
    }
    vector<vi> left(m), right(m);
    for (int i = 0; i < m; i++)
    {
        left[i] = smaller_or_equal_in_left(dp[i]);
        right[i] = smaller_or_equal_in_right(dp[i]);
    }
    int ans=0;
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (dp[i][j] != 0)
            {
                int height = dp[i][j];
                int left_b = j - left[i][j] - 1;
                int right_b;
                if (right[i][j] == -1)
                {
                    right_b = n - j - 1;
                }
                else
                {
                    right_b = right[i][j] - j - 1;
                }
                int temp_area = height * (left_b + 1 + right_b);
                ans = max(ans, temp_area);
            }
        }
    }
    cout << ans << endl;
    return 0;
}