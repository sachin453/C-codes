#include<bits/stdc++.h>
using namespace std;

int func(string A,int k,vector<int> &dp){
    if(k>=A.size()){
        return 1;
    }
    if(dp[k]!=-1){
        return dp[k];
    }
    else if(k==A.size()-1 && A[k]!='0'){
        return dp[k]= 1;
    }
    else if(A[k]=='0'){
        return dp[k]= 0;
    }
    else{
        int a=int(A[k])-48;
        int b=int(A[k+1])-48;
        int c=10*a+b;
        if(c>26){
            return dp[k]=func(A,k+1,dp);
        }
        else{
            return dp[k]= func(A,k+1,dp)+func(A,k+2,dp);
        }
    }
    return 0;
}

int efficient_func(string A){
    int g=0,h=0;
    for(int i=A.size()-1;i>=0;i--){
        if(i==A.size()-1 && A[i]!='0'){
            g=1;
        }
        else if(A[i]=='0'){
            h=g;
            g=0;
        }
        else{
            int a=int(A[i])-48;
            int b=int(A[i+1])-48;
            if(10*a+b>26){
                h=g;
            }
            else{
                int x=h;
                h=g;
                g=x+h;
            }
        }
    }
    return g;
}





int main(){
    string A="199";
    vector<int> dp(A.size(),-1);
    int ans1=func(A,0,dp);
    int ans2=efficient_func(A);
    cout<<ans1;
    cout<<endl<<ans2;
    return 0;
}