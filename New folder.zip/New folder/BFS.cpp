#include<bits/stdc++.h>
using namespace std;
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}
void print_vec(vector<int> v)
{ // prints the given vector
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}




int main(){
    init_code();
    int nodes,edges;
    cin>>nodes>>edges;
    vector<int> node_values(nodes);
    for(int i=0;i<nodes;i++){
        cin>>node_values[i];
    }
    vector<vector<int>> g(nodes);
    for(int i=0;i<edges;i++){
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    return 0; 
}