#include<iostream>
using namespace std;
#include<vector>

int fabonacci_number_dp(int n){
    vector<int> V(n,0);
    if(n==1 || n==2){
        return n;
    }
    else{
        V[0]=1;V[1]=2;
        if(V[n-1]!=0){
            return V[n-1];
        }
        else{
            V[n-2]=fabonacci_number_dp(n-1);
            V[n-3]=fabonacci_number_dp(n-2);
            V[n-1]=V[n-2]+V[n-3];
            return V[n-1];
        }
    }
}

int fabonacci_number_loop(int n){
    vector<int> V(n,0);
    if(n==1 || n==2){
        return n;
    }
    else{
        V[0]=1;
        V[1]=2;
        for(int i=2;i<n;i++){
            V[i]=V[i-1]+V[i-2];
        }
        return V[n-1];
    }
}


int main(){
    cout<<fabonacci_number_dp(25)-fabonacci_number_loop(24);
    return 0;
}