#include<bits/stdc++.h>
using namespace std;

stack<int> s,ss;



void pushh(int n){
    if(s.top()==-1){
        s.push(n);
        ss.push(n);
    }
    else{
        s.push(n);
        if(n<ss.top()){
            ss.push(n);
        }
    }
}


void popp(){
    if(s.top()!=-1){
        if(s.top()==ss.top()){
            s.pop();
            ss.pop();
        }
        else{
            s.pop();
        }
    }
}


int minn(){
    return ss.top();
}







int main(){
    s.push(-1);
    ss.push(-1);
    pushh(3);
    pushh(6);
    pushh(1);
    pushh(12);
    popp();
    popp();
    cout<<minn();
    return 0;
}