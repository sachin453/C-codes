#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}




int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        string s;
        cin>>s;
        int n=s.size();
        vi left_C(n),left_D(n),left_q(n),right_C(n),right_D(n),right_q(n);
        int lc=0,ld=0,lq=0;
        int rc=0,rd=0,rq=0;
        for(int i=0;i<n;i++){
            if(s[i]=='('){
                lc++;
                left_C[i]=lc;
                left_D[i]=ld;
                left_q[i]=lq;
            }
            else if(s[i]==')'){
                ld++;
                left_C[i]=lc;
                left_D[i]=ld;
                left_q[i]=lq;
            }
            else{
                lq++;
                left_C[i]=lc;
                left_D[i]=ld;
                left_q[i]=lq;
            }
            int j=n-1-i;
            if(s[j]=='('){
                rc++;
                right_C[j]=rc;
                right_q[j]=rq;
                right_D[j]=rd;
            }
            else if(s[j]==')'){
                rd++;
                right_C[j]=rc;
                right_q[j]=rq;
                right_D[j]=rd;
            }
            else{
                rq++;
                right_C[j]=rc;
                right_q[j]=rq;
                right_D[j]=rd;
            }
        }
        int ans=false;
        for(int i=0;i<n;i++){
            if(left_C[i]-left_D[i]+left_q[i]<=0 || right_D[i]-right_C[i]+right_q[i]<=0){
                ans=true;
                break;
            }
        }
        if(n==2){
            cout<<"YES"<<endl;
        }
        else if(ans){
            cout<<"YES"<<endl;
        }
        else{
            cout<<"NO"<<endl;
        }
    }
	return 0;
}
