#include<bits/stdc++.h>
using namespace std;
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}
void print_vec(vector<int> v)
{ // prints the given vector
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}
void dfs(vector<vector<int>> g,int node,int par,vector<int> &parents){
    for(int child:g[node]){
        if(child==par)continue;
        parents[child]=node;
        dfs(g,child,node,parents);
    }
}
void lca(vector<vector<int>> g,int A,int B){
    int nodes=g.size();
    vector<int> path_A,path_B,parents(nodes);
    parents[0]=-1;
    dfs(g,0,-1,parents);
    print_vec(parents);
    path_A.push_back(A);
    path_B.push_back(B);
    int x=A,y=B;
    while(parents[x]!=-1){
        path_A.push_back(parents[x]);
        x=parents[x];
    }
    while(parents[y]!=-1){
        path_B.push_back(parents[y]);
        y=parents[y];
    }
    int ans=0;
    print_vec(path_A);
    print_vec(path_B);
    map<int,int> mp;
    for(int i=0;i<path_A.size();i++){
        mp[path_A[i]]=1;
    }
    for(int i=0;i<path_B.size();i++){
        if(mp[path_B[i]]==1){
            ans=path_B[i];
            break;
        }
    }
    cout<<ans<<endl;
}
int main(){
    init_code();
    int nodes,edges;
    cin>>nodes>>edges;
    vector<vector<int>> g(nodes);
    for(int i=0;i<edges;i++){
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    lca(g,14,11);
    return 0; 
}