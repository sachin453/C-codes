 st.push(i);
            }