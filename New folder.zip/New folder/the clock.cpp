#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}




string func(int h,int m,int x){
    int m_=x%60;
    int h_=x/60;
    int hr=0,mr=0;
    if(m+m_<60){
        mr=m+m_;
    }
    else{
        hr++;
        mr=(m+m_)%60;
    }
    hr=(h+hr+h_)%24;
    int fr= hr*100+mr;
    string ans="0000";
    int x1=fr/1000;
    ans[0]=(char)(48+x1);
    fr=fr%1000;
    x1=fr/100;
    ans[1]=(char)(48+x1);
    fr=fr%100;
    x1=fr/10;
    ans[2]=(char)(48+x1);
    fr=fr%10;
    ans[3]=(char)(48+fr);
    return ans;
}




int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        string s;
        cin>>s;
        int x;
        cin>>x;
        string s1;
        s1.push_back(s[0]);
        s1.push_back(s[1]);
        s1.push_back(s[3]);
        s1.push_back(s[4]);
        int h0=s[0]-48;
        int h1=s[1]-48;
        int m0=s[3]-48;
        int m1=s[4]-48;
        int h=h0*10+h1;
        int m=m0*10+m1;
        int count=0;
        if(h0==m1 && h1==m0){
            count++;
        }
        string s2=func(h,m,x);
        while(s2!=s1){
            string str=func(h,m,x);
            if(str[0]==str[3] && str[1]==str[2]){
                count++;
            }
            int m_=x%60;
            int h_=x/60;
            int hr=0,mr=0;
            if(m+m_<60){
                mr=m+m_;
            }
            else{
                hr++;
                mr=(m+m_)%60;
            }
            hr=(h+hr+h_)%24;
            h=hr;
            m=mr;
            s2=func(h,m,x);
        }
        cout<<count<<endl;
    }
	return 0;
}
