#include<bits/stdc++.h>
using namespace std;


vector<vector<int>> func(vector<int> v,int sum){
    vector<vector<int>> ans={};
    sort(v.begin(),v.end());
    int n=v.size();
    int i=0;int j=n-1;
    for(;j>i;){
        if(v[i]+v[j]>sum){
            j--;
        }
        else if(v[i]+v[j]<sum){
            i++;
        }
        else{
            vector<int> A(2,0);
            A[0]=v[i];
            A[1]=v[j];
            ans.push_back(A);
            i++;
        }
    }
    return ans;
}


int main(){
    vector<int> v={-7,-3,-1,3,8,12};
    int sum=-4;
    vector<vector<int>> ans=func(v,sum);
    for(int i=0;i<ans.size();i++){
        vector<int> va=ans[i];
        cout<<va[0]<<" "<<va[1]<<"\n";
    }
    return 0;
}