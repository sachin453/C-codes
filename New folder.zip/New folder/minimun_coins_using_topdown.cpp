#include<bits/stdc++.h>
using namespace std;
int min1(int a,int b){
    return a>b?b:a;
}

int min_coins_topdown(int coins[],int n,int sum){
    int dp[n][sum+1];
    memset(dp,INT_MAX-1,sizeof(dp));
    for(int i=0;i<n;i++){
        for(int j=0;j<sum+1;j++){
            if(i==0 && j!=0){
                if(j%coins[i]==0){
                    dp[i][j]=j/coins[i];
                }
            }
            else if(j==0){
                dp[i][j]=0;
            }
            else{
                if(j<coins[i]){
                    dp[i][j]=dp[i-1][j];
                }
                else{
                    dp[i][j]=min1(dp[i-1][j],1+dp[i][j-coins[i]]);
                }
            }
        }
    }
    return dp[n-1][sum];
}


int main(){
    int coins[]={8,13,17};
    int sum=8;
    cout<<min_coins_topdown(coins,3,sum);
    return 0;
}