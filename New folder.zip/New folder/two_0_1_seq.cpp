#include<bits/stdc++.h>
using namespace std;





// void init_code()
// {
//     freopen("input.txt", "r", stdin);
//     // freopen("output.txt", "w", stdout);
// }

int main(){
    //init_code();
    int t;
    cin>>t;
    while(t--){
        int a,b;
        cin>>a>>b;
        string A,B;
        cin>>A>>B;
        string S;
        while(A[a-1]==B[b-1]) {
            S.push_back(A[a-1]);
            a--;b--;
            if(a==0 || b==0){
                break;
            }
        }
        int s=S.size();
        int al=A.size()-s;
        int bl=B.size()-s;
        if(bl==0){
            cout<<"YES"<<endl;
        }
        else if(bl==1){
            string ans="NO";
            for(int i=0;i<al;i++){
                if(A[i]==B[0]){
                    ans="YES";
                }
            }
            cout<<ans<<endl;
        }
        else{
            cout<<"NO"<<endl;
        }
        //cout<<S<<endl;
    }
    return 0;
}