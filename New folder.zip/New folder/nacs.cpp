#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}




int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        string w;
        int p;
        cin>>w;
        cin>>p;
        int n=w.size();
        vi nums(n);
        int price=0;
        for(int i=0;i<n;i++){
            nums[i]=int(w[i])-96;
            price+=nums[i];
        }
        unordered_map<int,int> mp;
        sort(nums.begin(),nums.end());
        for(int i=n-1;i>=0;i--){
            if(price>p){
                price-=nums[i];
                mp[nums[i]]+=1;
            }
        }
        for(int i=0;i<n;i++){
            int x=int(w[i])-96;
            if(mp[x]>0){
                w[i]='X';
                mp[x]--;
            }
        }
        for(int i=0;i<n;i++){
            if(w[i]!='X'){
                cout<<w[i];
            }
        }
        cout<<endl;
    }
	return 0;
}
