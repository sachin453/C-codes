#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}
vector<int> get_vec_range(int a,int b){ // returns a vector containing intergers in range [a,b] 
    vector<int> ans;                     // in increasing order
    for(int i=a;i<=b;i++){
        ans.push_back(i);
    }
    return ans;
}




int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vi nums=get_vec_range(1,n);
        vi marks(n,0);
        vi ans;
        for(int i=1;i<=n;i++){
            if(marks[i-1]==0){
                int x=i;
                while(x<=n){
                    ans.push_back(x);
                    marks[x-1]=1;
                    x=2*x;
                }
            }
        }
        cout<<2<<endl;
        print_vec(ans);
    }
	return 0;
}
