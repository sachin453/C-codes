#include<bits/stdc++.h>
using namespace std;
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}
void print_vec(vector<int> v)
{ // prints the given vector
    for (int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}



void dfs(vector<vector<int>> g,int node,int par,vector<int> node_values,vector<int> &node_sums,vector<int> &parents){
    node_sums[node]=node_values[node];
    for(int child:g[node]){
        if(child==par)continue;
        parents[child]=node;
        dfs(g,child,node,node_values,node_sums,parents);
        node_sums[node]+=node_sums[child];
    }
}


void delete_edge(vector<vector<int>> g,vector<int> node_values){
    int nodes=g.size();
    vector<int> node_sums(nodes),parents(nodes);
    parents[0]=-1;
    dfs(g,0,-1,node_values,node_sums,parents);
    print_vec(node_sums);
    print_vec(parents);
    int ans=INT_MIN;
    int total=accumulate(node_values.begin(),node_values.end(),0);
    for(int i=0;i<g.size();i++){
        for(int j=0;j<g[0].size();j++){
            int p=i,c=j;
            if(parents[i]=j){
                c=i;
                p=j;
                int sum1=node_sums[c];
                int sum2=total-sum1;
                int prod=sum1*sum2;
                ans=max(ans,prod);
            }
        }
    }
    cout<<ans<<endl;
}








int main(){
    init_code();
    int nodes,edges;
    cin>>nodes>>edges;
    vector<int> node_values(nodes);
    for(int i=0;i<nodes;i++){
        cin>>node_values[i];
    }
    vector<vector<int>> g(nodes);
    for(int i=0;i<edges;i++){
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    delete_edge(g,node_values);
    return 0; 
}