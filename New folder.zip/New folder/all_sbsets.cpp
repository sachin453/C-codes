#include<bits/stdc++.h>
using namespace std;



int main(){
    vector<int> v={1,2,3};
    vector<vector<int>> ans={};
    cout<<"sachin";
    return 0;
}