#include<iostream>
using namespace std;

int max(int a,int b){
    return a>b?a:b;
}


int main(){
    int t;
    cin>>t;
    while(t--){
        int n,m;
        cin>>n>>m;
        int matrix[n][m];
        int i1=0;int j1=0;
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                cin>>matrix[i][j];
                if(matrix[i][j]>=matrix[i1][j1]){
                    i1=i;j1=j;
                }
            }
        }
        int a=(i1+1)*(j1+1);
        int b=(i1+1)*(m-j1);
        int c=(n-i1)*(j1+1);
        int d=(n-i1)*(m-j1);
        int ans=max(a,max(b,max(c,d)));
        cout<<ans<<endl;
    }
}
