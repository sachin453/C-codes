#include<bits/stdc++.h>
using namespace std;

struct node{
    int val;
    node* left;
    node* right;
};

node* create_node(int n){
    node* node1= new node();
    node1->val=n;
    node1->left=NULL;
    node1->right=NULL;
    return node1;

}



node* insrt_node(node* root,int n){
    if(!root){
        return create_node(n);
    }
    else{
        if(root->val>n){
            root->left=insrt_node(root->left,n);
        }
        else{
            root->right=insrt_node(root->right,n);
        }
    }
    return root;
}



int solve(node* root,int& res){
    if(root==NULL){
        return 0;
    }
    int l=solve(root->left,res);
    int r=solve(root->right,res);


    int temp=1+max(l,r);
    res=max(res,1+l+r);
    return temp;
}


int maximum_sum_path(node* root,int& sum){
    if(!root){
        return 0;
    }
    int l=maximum_sum_path(root->left,sum);
    int r=maximum_sum_path(root->right,sum);
    int m=root->val;
    int temp = max(m,max(m + l, m + r));
    sum=max(m+l+r,max(temp,sum));
    return temp;
}


int maximum_sum_path_leaf_to_leaf(node* root,int& sum){
    if(!root){
        return 0;
    }
    int l=maximum_sum_path_leaf_to_leaf(root->left,sum);
    int r=maximum_sum_path_leaf_to_leaf(root->right,sum);
    int m=root->val;
    int temp = max(m + l, m + r);
    sum=max(sum,m+l+r);
    return temp;
}




int main(){
    node* root= (node*) malloc(sizeof(node));
    root=NULL;
    root=insrt_node(root,50);
    root=insrt_node(root,-20);
    root=insrt_node(root,70);
    root=insrt_node(root,30);
    root=insrt_node(root,-10);
    //root=insrt_node(root,60);
    root=insrt_node(root,80);
    
    int res=INT_MIN;
    //solve(root,res);
    //cout<<root->left->left->val<<"\n";
    //cout<<res;

    int sum=INT_MIN;
    maximum_sum_path_leaf_to_leaf(root,sum);
    cout<<sum;
    
    return 0;
}

