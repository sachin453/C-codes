#include<bits/stdc++.h>
using namespace std;
int max(int a,int b){
    return a>=b?a:b;
}

int top_down(int wt[],int val[],int n,int W){
    int dp[12][101];
    memset(dp,-1,sizeof(dp));
    for(int i=0;i<12;i++){
        for(int j=0;j<101;j++){
            if(i==0 || j==0){
                dp[i][j]=0;
            }
            else if(j<wt[i-1]){
                dp[i][j]=dp[i-1][j];
            }
            else{
                dp[i][j]=max(val[i-1]+dp[i-1][j-wt[i-1]],dp[i-1][j]);
            }
        }
    }
    return dp[11][100];
}

int main(){
    int wt[]={1,3,4,6,7,9,10,13,24,45,67};
    int val[]={2,5,8,9,11,12,15,18,21,23,32};
    int W=100;
    cout<<top_down(wt,val,11,W);
    return 0;
}