
#include<bits/stdc++.h>
#define ll long long
#define vll vector<ll>
#define vi vector<int>
using namespace std;
int max(int a,int b){   // max of two ints 
    return a>b?a:b;
}
int min(int a,int b){  // min of two ints
    return a>b?b:a;
}
vi scan_vec(int n){   // scan and return a vector of length n
    vi v(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    return v;
}
void print_vec(vi v){   // prints the given vector
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}




int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        long int n;
        cin>>n;
        if(n%2==0){
            cout<<n/2<<" "<<0<<" "<<0<<endl;
        }
        else{
            cout<<-1<<endl;
        }
    }
	return 0;
}
