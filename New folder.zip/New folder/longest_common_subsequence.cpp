#include <bits/stdc++.h>
using namespace std;

int lcs(string s1, string s2)
{
    int n1 = s1.size();
    int n2 = s2.size();
    if (n1 == 0 || n2 == 0)
    {
        return 0;
    }
    else if (n2 == 1)
    {
        for (int i = 0; i < n1; i++)
        {
            if (s1[i] == s2[0])
            {
                return 1;
                break;
            }
        }
        return 0;
    }
    else
    {
        int k = -1;
        for (int i = 0; i < n1; i++)
        {
            if (s1[i] == s2[0])
            {
                k = i;
                break;
            }
        }
        if (k == -1)
        {
            s2 = s2.erase(0, 1);
            return lcs(s1, s2);
        }
        else
        {
            string s3 = s1.erase(0, k + 1);
            string s4 = s2.erase(0, 1);
            return 1 + lcs(s3, s4);
        }
    }
    return 0;
}

int lcs2(string s1, string s2, int n1, int n2, int dp[20][20])
{
    if (dp[n1][n2] != -1)
    {
        return dp[n1][n2];
    }
    if (n1 == 0 || n2 == 0)
    {
        return dp[n1][n2] = 0;
    }
    else
    {
        string s3, s4;
        s3 = s1;
        s3.pop_back();
        s4 = s2;
        s4.pop_back();
        if (s1[n1 - 1] == s2[n2 - 1])
        {
            return dp[n1][n2] = 1 + lcs2(s3, s4, n1 - 1, n2 - 1, dp);
        }
        else
        {
            return dp[n1][n2] = max(lcs2(s1, s4, n1, n2 - 1, dp), lcs2(s2, s3, n2, n1 - 1, dp));
        }
    }
}

int lcs_ss(string s1, string s2)
{
    int n1 = s1.size();
    int n2 = s2.size();
    int dp[n1 + 1][n2 + 1];
    int ans = 0;
    memset(dp, 0, sizeof(dp));
    for (int i = 0; i < n1 + 1; i++)
    {
        for (int j = 0; j < n2 + 1; j++)
        {
            if (i == 0 || j == 0)
            {
                dp[i][j] == 0;
            }
            else
            {
                if (s1[i - 1] == s2[j - 1])
                {
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                }
                else
                {
                    dp[i][j] = 0;
                }
            }
            if (dp[i][j] > ans)
            {
                ans = dp[i][j];
            }
        }
    }
    return ans;
}

int lcs_tpdn(string s1, string s2)
{
    int n1 = s1.size();
    int n2 = s2.size();
    int dp[n1 + 1][n2 + 1];
    memset(dp, 0, sizeof(dp));
    for (int i = 0; i < n1 + 1; i++)
    {
        for (int j = 0; j < n2 + 1; j++)
        {
            if (i == 0 || j == 0)
            {
                dp[i][j] == 0;
            }
            else
            {
                if (s1[i - 1] == s2[j - 1])
                {
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                }
                else
                {
                    dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }
    }
    return dp[n1][n2];
}

string lcs_print(string s1, string s2)
{
    int n1 = s1.size();
    int n2 = s2.size();
    string ans = "";
    int dp[n1 + 1][n2 + 1];
    memset(dp, 0, sizeof(dp));
    for (int i = 0; i < n1 + 1; i++)
    {
        for (int j = 0; j < n2 + 1; j++)
        {
            if (i == 0 || j == 0)
            {
                dp[i][j] == 0;
            }
            else
            {
                if (s1[i - 1] == s2[j - 1])
                {
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                }
                else
                {
                    dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }
    }
    int i = n1;
    int j = n2;
    while (i > 0 && j > 0)
    {
        if (s1[i - 1] == s2[j - 1])
        {
            ans += s1.substr(i - 1, 1);
            i--;
            j--;
        }
        else
        {
            if (dp[i - 1][j] > dp[i][j - 1])
            {
                i--;
            }
            else
            {
                j--;
            }
        }
    }
    for (int p = 0; p < ans.size() / 2; p++)
    {
        char c = ans[p];
        ans[p] = ans[ans.size() - 1 - p];
        ans[ans.size() - 1 - p] = c;
    }
    return ans;
}

int main()
{
    string s1 = "sachinkuntal";
    string s2 = "sxxhktyytal";
    int dp[20][20];
    memset(dp, -1, sizeof(dp));
    cout << lcs2(s1, s2, s1.size(), s2.size(), dp) << " <-> " << lcs(s1, s2) << " <-> " << lcs_tpdn(s1, s2) << " <-> " << lcs_ss(s1, s2);
    cout << "\n"
         << lcs_print(s1, s2);
    return 0;
}