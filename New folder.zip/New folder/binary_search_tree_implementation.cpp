#include <iostream>
using namespace std;

struct nodeBST
{
    /* data */
    int val;
    nodeBST *left;
    nodeBST *right;
};

void print_bst(nodeBST *&rut)
{
    if (rut != NULL)
    {
        cout << rut->val << " ";
    }
    else
    {
        return;
    }
    print_bst(rut->left);
    print_bst(rut->right);
}

nodeBST *get_new_node(int n)
{
    nodeBST *new_node = new (nodeBST);
    new_node->val = n;
    new_node->right = NULL;
    new_node->left = NULL;
    return new_node;
}

void insrt_node(nodeBST *&rut, int data)
{
    if (rut == NULL)
    {
        rut = get_new_node(data);
    }
    else
    {
        if (data >= rut->val)
        {
            insrt_node(rut->right, data);
        }
        else
        {
            insrt_node(rut->left, data);
        }
    }
}
int find_min(nodeBST *rut)
{
    if (rut->left == NULL)
    {
        return rut->val;
    }
    else
    {
        return find_min(rut->left);
    }
}
nodeBST *dilete(nodeBST *rut, int data)
{
    if (rut == NULL)
    {
        return NULL;
    }
    else
    {
        if (rut->val > data)
        {
            rut->left = dilete(rut->left, data);
        }
        else if (rut->val < data)
        {
            rut->right = dilete(rut->right, data);
        }
        else
        {
            if (rut->left == NULL && rut->right == NULL)
            {
                delete rut;
                rut = NULL;
                return rut;
            }
            else if (rut->left == NULL && rut->right != NULL)
            {
                nodeBST *node1;
                node1 = rut->right;
                delete rut;
                rut = node1;
                return rut;
            }
            else if (rut->left != NULL && rut->right == NULL)
            {
                nodeBST *node1;
                node1 = rut->left;
                delete rut;
                rut = node1;
                return rut;
            }
            else
            {
                int x = find_min(rut->right);
                rut->val = x;
                dilete(rut->right, x);
            }
        }
    }
    return rut;
}

int main()
{
    nodeBST *root = NULL;
    insrt_node(root, 50);
    insrt_node(root, 25);
    insrt_node(root, 100);
    insrt_node(root, 20);
    insrt_node(root, 30);
    insrt_node(root, 75);
    insrt_node(root, 150);
    insrt_node(root, 15);
    insrt_node(root, 21);
    insrt_node(root, 26);
    insrt_node(root, 31);
    insrt_node(root, 74);
    insrt_node(root, 76);
    insrt_node(root, 149);
    insrt_node(root, 151);
    print_bst(root);
    dilete(root, 50);
    cout<<endl;
    print_bst(root);
    cout << endl
         << find_min(root);

    return 0;
}