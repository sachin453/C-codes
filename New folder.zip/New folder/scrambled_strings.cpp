#include<bits/stdc++.h>
using namespace std;



int is_scrambled(string s1,string s2,int i,int j){
    if(i>j){
        return 0;
    }
    else if(j==i){
        if(s1[i]==s2[i]){
            return 1;
        }
        else{
            return 0;
        }
    }
    else if(j==i+1){
        if((s1[i]==s2[i] && s1[j]==s2[j]) || (s1[i]==s2[j] && s1[j]==s2[i])){
            return 1;
        }
        else return 0;
    }
    else{
        int ans=0;
        for(int k=i;k<j;k++){
            string s3=s2.substr(i,j-k);
            string s4=s2.substr(i+j-k,k-i+1);
            string s6="";
            s6+=s4;s6+=s3;
            string s5=s2;
            s5.replace(i,j-i+1,s6);
            ans=max(ans,max( min(is_scrambled(s1,s2,i,k) , is_scrambled(s1,s2,k+1,j)) , min(is_scrambled(s1,s5,i,k) , is_scrambled(s1,s5,k+1,j))  ));
        }
        return ans;
    }
    return 0;
}



int main(){
    string s1="sachinkuntal";
    string s2="talkunhinsac";
    int n=s1.length();

    int dp[50][50];
    memset(dp,-1,sizeof(dp));
    
    

    cout<<is_scrambled(s1,s2,0,n-1);
    return 0;
}