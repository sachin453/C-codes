#include <iostream>
#include <vector>
#include <cstring>
using namespace std;

bool if_loop_present(vector<vector<int>> graph, vector<int> &visited, int N, int p)
{
    bool ans = false;
    if (visited[p] == 0)
    {
        visited[p] = 1;
        for (int i = 0; i < graph[p].size(); i++)
        {
            int neig = graph[p][i];
            if (visited[neig] == 0)
            {
                for (int j = 0; j < graph[neig].size(); j++)
                {
                    int neig_neig = graph[neig][j];
                    if (visited[neig_neig] == 1 && p != neig_neig)
                    {
                        return true;
                    }
                }
                visited[neig] = 1;
                ans = ans || if_loop_present(graph, visited, N, neig);
            }
        }
    }
    return ans;
}

int total_no(vector<vector<int>> graph, vector<int> &visited, int N, int p)
{
    int ans = 0;
    if (visited[p] == 0)
    {
        visited[p] = 1;
        ans++;
        for (int i = 0; i < graph[p].size(); i++)
        {
            int neig = graph[p][i];
            if (visited[neig] == 0)
            {
                ans += total_no(graph, visited, N, neig);
            }
        }
    }
    return ans;
}

bool if_connected(vector<vector<int>> graph, int N, int p, int q)
{
    vector<int> visited(N,0);
    int no_of_vertices=total_no(graph,visited,N,p);
    if(visited[q]==1){
        return true;
    }
    return false;
}

int main()
{
    vector<vector<int>> graph = {{8,5},{2,3},{1,4},{1,4},{2,3},{0,6},{5,7},{8,6},{0,7}};
    int N = 9;
    vector<int> visited(N, 0);
    cout << if_connected(graph,N, 2, 0) << endl;
    
    
    
    cout << total_no(graph, visited, N, 0) << endl;
    
    
    
    for(int i=0;i<N;i++){
        cout<<visited[i]<<" ";
    }
    cout<<endl;
    
    
    
    vector<int> visited2(N, 0);
    visited = visited2;
    cout << if_loop_present(graph, visited, N, 1) << endl;
    
    
    
    
    return 0;
}
