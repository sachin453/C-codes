#include<bits/stdc++.h>
using namespace std;


int max(int a,int b){
    return a>b?a:b;
}

vector<int> nearest_smaller_right(vector<int> v){
    stack<int> st;
    st.push(-1);
    vector<int> ans;
    for(int i=v.size()-1;i>=0;i--){
        if(st.top()!=-1){
            if(v[i]>v[st.top()]){
                ans.push_back(st.top());
                st.push(i);
            }
            else{
                while(st.top()>=0 && v[i]<=v[st.top()]){
                    st.pop();
                }
                if(v[st.top()]<v[i]){
                    ans.push_back(st.top());
                    st.push(i);
                }
                else{
                    ans.push_back(-1);
                    st.push(i);
                }
            }
        }
        else{
            ans.push_back(-1);
            st.push(i);
        }
    }
    reverse(ans.begin(),ans.end());
    return ans;
}


vector<int> nearest_smaller_left(vector<int> v){
    stack<int> st;
    st.push(-1);
    vector<int> ans;
    for(int i=0;i<v.size();i++){
        if(st.top()!=-1){
            if(v[i]>v[st.top()]){
                ans.push_back(st.top());
                st.push(i);
            }
            else{
                while(st.top()>=0 && v[i]<=v[st.top()]){
                    st.pop();
                }
                if(v[st.top()]<v[i]){
                    ans.push_back(st.top());
                    st.push(i);
                }
                else{
                    ans.push_back(-1);
                    st.push(i);
                }
            }
        }
        else{
            ans.push_back(-1);
            st.push(i);
        }
    }
    return ans;
}

int func(vector<int> v,vector<int> vleft,vector<int> vright){
    int n=v.size();
    int ans=0;
    for(int i=0;i<v.size();i++){
        if(vleft[i]!=-1 && vright[i]!=-1){
            ans=max(ans,v[i]*(vright[i]-vleft[i]-1));
        }
        else if(vleft[i]==-1 && vright[i]!=-1){
            ans=max(ans,v[i]*(vright[i]));
        }
        else if(vleft[i]!=-1 && vright[i]==-1){
            ans=max(ans,v[i]*(n-vleft[i]-1));
        }
        else{
            ans=max(ans,v[i]*(n));
        }
    }
    return ans;
}


int main(){
    vector<int> v={6,2,5,4,5,1,6};
    int ans=func(v,nearest_smaller_left(v),nearest_smaller_right(v));
    cout<<ans;
    return 0;
}