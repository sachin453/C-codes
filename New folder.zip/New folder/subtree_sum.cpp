#include<bits/stdc++.h>
using namespace std;
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}

int func1(vector<vector<int>> g,vector<bool> &visited,vector<int> node_values,int node,vector<int> &node_sums){
    if(visited[node])return 0;
    visited[node]=true;
    int ans=node_values[node];
    for(int i=0;i<g[node].size();i++){
        if(!visited[g[node][i]]){
            ans+=func1(g,visited,node_values,g[node][i],node_sums);
        }
    }
    node_sums[node]=ans;
    return ans;
}

void sum_of_subtrees(vector<vector<int>> g,vector<int> node_values){
    int nodes=g.size();
    vector<int> sub_tree_sum(nodes,0);
    vector<bool> visited(nodes,false);
    func1(g,visited,node_values,0,sub_tree_sum);
    cout<<"sum of subtrees are : \n";
    for(int i=0;i<sub_tree_sum.size();i++){
        cout<<i<<"->"<<sub_tree_sum[i]<<endl;
    } 
}

int func2(vector<vector<int>> g,vector<bool> &visited,int node,vector<int> node_values,vector<int> &evens){
    if(visited[node])return 0;
    visited[node]=true;
    int ans=0;
    if(node_values[node]%2==0){
        ans++;
    }
    for(int i=0;i<g[node].size();i++){
        if(!visited[g[node][i]]){
            ans+=func2(g,visited,g[node][i],node_values,evens);
        }
    }
    evens[node]=ans;
    return ans;
}


void no_of_even_nodes(vector<vector<int>> g,vector<int> node_values){
    int nodes=g.size();
    vector<bool> visited(nodes,false);
    vector<int> evens(nodes,0);
    func2(g,visited,0,node_values,evens);
    cout<<"sum of even are : \n";
    for(int i=0;i<evens.size();i++){
        cout<<i<<"->"<<evens[i]<<endl;
    } 
}


int main(){
    init_code();
    int nodes,edges;
    cin>>nodes>>edges;
    vector<int> node_values(nodes);
    for(int i=0;i<nodes;i++){
        cin>>node_values[i];
    }
    vector<vector<int>> g(nodes);
    for (int i = 0; i < edges; i++)
    {
        int x, y;
        cin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    sum_of_subtrees(g,node_values);
    no_of_even_nodes(g,node_values);
    return 0;
}