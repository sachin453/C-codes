#include<bits/stdc++.h>
using namespace std;


int func(vector<int> v){
    int n=v.size();
    if(n==0 || n==1)
    return 0;
}




int main(){
    vector<int> v1={1,6,11,5};
    int n=v1.size();
    vector<int> v2(n,0);
    int sum=accumulate(v1.begin(),v1.end(),0);
    return 0;
}