#include<bits/stdc++.h>
using namespace std;

int main(){
    vector<int> v={9,9,3,2,7,6,8,4,9,2,5,6,8,1,2,5,9,3,7,4,2,7,8};
    stack<int> st;
    st.push(-1);
    vector<int> ans;
    for(int i=0;i<v.size();i++){
        if(st.top()!=-1){
            if(v[st.top()]>v[i]){
                ans.push_back(st.top());
                st.push(i);
            }
            //else if(v[st.top()]==v[i]){
            //    ans.push_back(st.top());
            //    st.push(i);
            //}
            else{
                while(st.top()!=-1 && v[st.top()]<v[i]){
                    st.pop();
                }
                if(st.top()==-1){
                    ans.push_back(-1);
                    st.push(i);
                }
                else {
                    ans.push_back(st.top());
                    st.push(i);
                }
            }
        }
        else{
            ans.push_back(-1);
            st.push(i);
        }
    }
    vector<int> ansf;
    for(int i=0;i<v.size();i++){
        if(ans[i]==-1){
            ansf.push_back(0);
        }
        else{
            ansf.push_back(i-ans[i]-1);
        }
    }
    for(int i=0;i<ansf.size();i++){
        cout<<ansf[i]<<" ";
    }
    cout<<endl;
    for(int i=0;i<ansf.size();i++){
        //cout<<v[i]<<" ";
    }
    return 0;
}