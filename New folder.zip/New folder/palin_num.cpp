#include <iostream>
#include<vector>
using namespace std;


string func(string s,int len){
    string ans;
    if(s[0]!='9'){
        for(int i=0;i<len;i++){
            char c=(char)(57-(int(s[i])-48));
            ans.push_back(c);
        }
    }
    else{
        string pr;
        for(int i=0;i<=len;i++){
            pr.push_back('1');
        }
        s="0"+s;
        int carr=0;
        for(int i=len;i>=0;i--){
            int u=(int(pr[i])-48);
            int l=(int(s[i])-48);
            if(u+carr>=l){
                ans.push_back((char)(48+u+carr-l));
            }
            else{
                ans.push_back((char)(48+u+carr-l+10));
                carr=-1;
            }
        }
        string fans;
        for(int i=ans.size()-2;i>=0;i--){
            fans.push_back(ans[i]);
        }
        ans=fans;
    }
    return ans;
}



int main() {
	int t;
	cin>>t;
	while(t--){
	    int len;
	    cin>>len;
	    string s;
	    cin>>s;
	    cout<<func(s,len)<<endl;
	}
	return 0;
}
