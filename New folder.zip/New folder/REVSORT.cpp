#include <iostream>
#include<vector>
using namespace std;

long sum_i_j(int i,int j,vector<long int> sum,vector<int> A){
    return sum[j]-sum[i]+A[i];
}



int main() {
	int T;
	cin>>T;
	while(T--){
	    int N,X;
	    cin>>N>>X;
	    vector<int> A(N);
	    for(int i=0;i<N;i++){
	        cin>>A[i];
	    }
	    vector<long> sum(N);
	    sum[0]=A[0];
	    for(int i=0;i<N;i++){
	        if(i!=0){
	            sum[i]=A[i]+sum[i-1];
	        }
	    }
	    vector<pair<int,int>> vpr;
	    int high=N-1,low=N-1;
	    for(int i=N-2;i>=0;i--){
	        if(A[i]>=A[i+1]){
	            low--;
	            if(i==0){
	                pair<int,int> pr;
	                pr.first=low;
	                pr.second=high;
	                vpr.push_back(pr);
	            }
	        }
	        else{
	            pair<int,int> pr;
	            pr.first=low;
	            pr.second=high;
	            vpr.push_back(pr);
	            low=i;
	            high=i;
	            if(i==0){
	                pair<int,int> pr;
	                pr.first=low;
	                pr.second=high;
	                vpr.push_back(pr);
	            }
	        }
	    }
	    
	    
	    string x="YES";
	    for(int i=0;i<vpr.size();i++){
	        int low1=vpr[i].first;
	        int high1=vpr[i].second;
	        if(A[low1]!=A[high1] && sum_i_j(low1,high1,sum,A)>X){
	            x="NO";
	            break;
	        }
	        if(A[low1]!=A[high1]){
	            vector<int> temp;
	            for(int j=low1;j<=high1;j++){
	                temp.push_back(A[j]);
	            }
	            for(int j=low1;j<=high1;j++){
	                A[j]=temp[high1-j];
	            }
	        }
	    }
	    if(x!="NO"){
	        for(int i=1;i<N;i++){
	            if(A[i]<A[i-1]){
	                x="NO";
	                break;
	            }
	        }
	    }
	    cout<<x<<endl;
	}
	return 0;
}
