#include<iostream>
using namespace std;

int* temp(int* arr,int n,int k){
    int arr1[n+1];
    for(int i=0;i<n;i++){
        if(*arr<k){
            arr1[i]=*arr;
        }
        else if(*arr==k){
            arr1[i]=k;
        }
        else{

        }
    }
}



int* func(int* arr,int n){
    if(n==1){
        return arr;
    }
    else{

    }
}




int main(){
    int arr[]={9,1,8,2,7,3,6,4};
    return 0;
}