#include<bits/stdc++.h>
using namespace std;
void init_code()
{
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
}


void dfs(vector<vector<int>> &g,int srx,int sry,vector<vector<bool>> &visited,int new_color){
    if(srx<0 || sry<0 || srx>=g.size() || sry>=g[0].size())return;
    if(visited[srx][sry] || g[srx][sry]==0)return;
    visited[srx][sry]=true;
    g[srx][sry]=new_color;
    dfs(g,srx+1,sry,visited,new_color);
    dfs(g,srx-1,sry,visited,new_color);
    dfs(g,srx,sry+1,visited,new_color);
    dfs(g,srx,sry-1,visited,new_color);
}




int main(){
    init_code();
    int m,n;
    cin>>m>>n;
    vector<vector<int>> g(m,vector<int> (n));
    vector<vector<bool>> visited(m,vector<bool> (n,false));
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>g[i][j];
        }
    }
    int srx,sry;
    cin>>srx>>sry;
    int new_color;
    cin>>new_color;
    dfs(g,srx,sry,visited,new_color);
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cout<<g[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
}